/* --------------------------------------------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 * ------------------------------------------------------------------------------------------ */

import {
 createConnection,
 ProposedFeatures,
} from "vscode-languageserver";
import { initDiagnostic } from "./diagnostic";
import { IpcListener } from "./se/listener";

// Create a connection for the server. The connection uses Node's IPC as a transport.

const connection = createConnection(ProposedFeatures.all);
initDiagnostic(connection);

connection.console.info(`Gondola server running in node ${process.version}`);

const listener = new IpcListener();
connection.onRequest(onReceiveMessage );

function onReceiveMessage(method: string, params: any) {
    return listener.onMessage(method, params);
}

// Listen on the connection
connection.listen();
