import * as TypeScript from "typescript"; // this is a dev dependency only. only use for typecheck, do not use directly
import { Files } from "vscode-languageserver";
import { info } from "./diagnostic";

declare const __webpack_require__: typeof require;
declare const __non_webpack_require__: typeof require;
export function loadNodeModule<T>(moduleName: string): T | undefined {
    const r = typeof __webpack_require__ === "function" ? __non_webpack_require__ : require;
    try {
        return r(moduleName);
    } catch (err) {
        // Not available.
    }
    return undefined;
}

type PackageManagers = "npm" | "yarn" | "pnpm";

function trace(message: string, verbose?: string): void {
    info(`${message}}`);
}

// tslint:disable-next-line: variable-name
const _globalPaths: { [key: string]: { cache: string; get(): string; } } = {
    yarn: {
        cache: undefined,
        get(): string {
            return Files.resolveGlobalYarnPath();
        },
    },
    npm: {
        cache: undefined,
        get(): string {
            return Files.resolveGlobalNodePath();
        },
    },
};


const globalLibrariesPath: { [libName: string]: string} = {};

async function  getPathOfGlLib(libName: string) {
    let libPath = globalLibrariesPath[libName];
    if (!libPath) {
        const npmGlobal = globalPathGet("npm");
        libPath = await Files.resolve(libName, npmGlobal, undefined, trace);
        globalLibrariesPath[libName] = libPath;
    }
    return libPath;
}

const tsPath2Library: Map<string, typeof TypeScript> = new Map<string, typeof TypeScript>();

function globalPathGet(packageManager: PackageManagers): string {
    const pm = _globalPaths[packageManager];
    if (pm) {
        if (pm.cache === undefined) {
            pm.cache = pm.get();
        }
        return pm.cache;
    }
    return undefined;
}

async function getTypescript(cwd?: string): Promise<typeof TypeScript | undefined> {
    const pathLib = await  getPathOfGlLib("typescript");
    let library = tsPath2Library.get(pathLib);
    if (!library) {
        library = loadNodeModule(pathLib);
        if (library) {
            tsPath2Library.set(pathLib, library);
            return library;
        }
    }
    return library;
}

export {
    getTypescript,
};
