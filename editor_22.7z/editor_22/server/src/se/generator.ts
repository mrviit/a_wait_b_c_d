import * as fs from "fs";
import * as path from "path";
import { promisify } from "util";
import { createLogger } from "../diagnostic";
import DictionaryGenerator from "./common/dictionary";
import DOMConverter from "./converter/dom_converter";
import SEConverter from "./converter/se_converter";
import TSConverter from "./converter/ts_converter";

const writeFile = promisify(fs.writeFile);
enum ViewType {
    TEST_VIEW = 1,
    PAGE_OBJECT_VIEW,
}

export default class Generator {

    public static async generateSE(workingDir: string, tsFilePath: string, fileType: number) {
        const logFn = createLogger("generateSE");
        let resSE = {};
        if (fileType === ViewType.TEST_VIEW) {
            logFn("Start DOMConverter.convertFromTS");
            const resDOM = await DOMConverter.convertTestModuleFromTS(tsFilePath);
            logFn("Start SEConverter.convertFromDOM");
            resSE = SEConverter.convertFromDOM(workingDir, resDOM);
        } else if (fileType === ViewType.PAGE_OBJECT_VIEW) {
            logFn("Start DOMConverter.convertPageObjectFromTS");
            const resDOM = await DOMConverter.convertPageObjectFromTS(tsFilePath);
            logFn("Start SEConverter.convertFromDOM");
            resSE = SEConverter.convertFromPageObjectDOM(workingDir, resDOM);
        }
        logFn("End generateSE");
        return resSE;
    }

    public static async generateTS(data: any, workingDir: string, filepath: string) {
        const logFn = createLogger("generateTS");
        let resTS: string;
        if (data.hasOwnProperty("locators") || data.hasOwnProperty("methods")) {
            logFn("Start DOMConverter.convertFromPageObject");
            const resDOM = DOMConverter.convertFromPageObject(workingDir, data);
            resDOM.pageobject = path.parse(filepath).name;
            logFn("Start TSConverter.convertPageObjectFromDOM");
            resTS = await TSConverter.convertPageObjectFromDOM(resDOM);
        } else {
            logFn("Start DOMConverter.convertFromSE");
            const resDOM = DOMConverter.convertFromSE(workingDir, data);
            logFn("Start TSConverter.convertTestModuleFromDOM");
            resTS = await TSConverter.convertTestModuleFromDOM(resDOM);
        }
        logFn("Start _writeToFile");
        await this._writeToFile(resTS, filepath);

        logFn("End generateTS");
    }

    private static async _writeToFile(data: string, filePath: string) {
        try {
            const info = path.parse(filePath);
            const output = path.join(`${info.dir}`, `${info.name}.ts`);

            await writeFile(output, data);
        } catch (e) {
            // tslint:disable-next-line: no-console
            console.log(e.message);
        }
    }
}
