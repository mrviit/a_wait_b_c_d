
export const HookMap = {
    BeforeSuite: "Suite Initial",
    AfterSuite: "Suite Final",
    Before: "Test Initial",
    After: "Test Final",
};

export enum ItemType {
    TestModule = 1,
    TestHook,
    TestCase,
    Action,
}

export interface IPageObjectInfo {
    name: string;
    location: string;
}
export interface ITestItem {
    skip?: boolean;
    type?: ItemType;
    children?: ITestItem[];
    usingPOs?: IPageObjectInfo[];
}

export interface ITestModule extends ITestItem {
    testmodule: string;
    tags?: string[];
}

export interface ITestCase extends ITestItem {
    testcase: string;
    tags?: string[];
}

export interface IAction extends ITestItem {
    action: string;
    args: any[];
    return?: string;
}

export interface ITestHook extends ITestItem {
    hook: string;
}

export interface IComment {
    comment: string;
    offset: number;
}

export interface IPageObject extends ITestItem {
    pageobject: string;
}

export interface ILocator extends ITestItem {
    name: string;
    value: string;
}

export interface IMethod extends ITestItem {
    method: string;
    params: IParameter[];
    return?: any;
    des?: string[];
}

export interface IParameter {
    name: string;
    type: string;
    default?: any;
}
