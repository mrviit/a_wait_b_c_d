import * as fs from "fs";
import * as path from "path";

import * as TypeScript from "typescript";
import { getTypescript } from "../../libloader";
import { doesNodeHaveDecorator } from "../utils/util";
interface IArg {
    [key: string]: string;
}

export interface IActionDef {
    keyword: string;
    method: string;
    instance?: string;
    description?: string;
    path?: string;
    args?: IArg[];
    return?: boolean;
}

export interface ILocatorDef {
    locator: string;
    instance?: string;
    path?: string;
}

export default class DictionaryGenerator {
    public static async generateDictionary(projectPath: string) {
        await this._initState();

        const actionPropertyMap = this.getDictionary(projectPath);
        if (actionPropertyMap.length > 0) {
            return actionPropertyMap;
        }

        const inputFile = path.join(projectPath, "node_modules/gondolajs/built/builtin.d.ts");
        if (!fs.existsSync(inputFile)) {
            this.dictsMap.set(projectPath, []);
            return [];
        }

        const sourceText = fs.readFileSync(inputFile, "utf-8");

        const sourceNode = this.ts.createSourceFile(
            inputFile,
            sourceText,
            this.ts.ScriptTarget.Latest,
            true);

        sourceNode.statements.forEach((interfaceNode) => {
            if (!this.ts.isInterfaceDeclaration(interfaceNode)) {
                return;
            }
            const interfaceName = interfaceNode.name.getText();
            if (!["IGondola", "IGondolaMobile", "IRestApi", "IResemble"].includes(interfaceName)) {
                return;
            }
            interfaceNode.members.forEach((methodNode) => {
                if (!this.ts.isMethodSignature(methodNode)) {
                    return;
                }
                const args: any[] = [];
                methodNode.parameters.forEach((paramNode) => {
                    const paramInfo = { [paramNode.name.getText()]: paramNode.type ? paramNode.type.getText() : "" };
                    args.push(paramInfo);
                });
                const type = methodNode.type.getText();
                let actionReturn = false;
                if (type !== "void" && type !== "Promise<void>") {
                    actionReturn = true;
                }

                const method = methodNode.name.getText();
                const keyword = this._genKeyword(method);
                const instance = "gondola";
                const methodDeclaration = methodNode as any;
                const actionProperty: IActionDef = {
                    method,
                    args,
                    keyword,
                    instance,
                    description: methodDeclaration.jsDoc[0].comment,
                    return: actionReturn,
                };

                actionPropertyMap.push(actionProperty);
            });
        });

        const unknownAction = {
            method: "unknown",
            args: [
                { arg1: "string" },
                { arg2: "string" },
                { arg3: "string" },
                { arg4: "string" },
            ],
            keyword: "unknown",
            instance: "gondola",
            description: "",
            return: false,
        };
        actionPropertyMap.push(unknownAction);

        this.dictsMap.set(projectPath, actionPropertyMap);
        return actionPropertyMap;
    }

    public static getDictionary(projectPath: string): any[] {
        const existDict = this.dictsMap.get(projectPath);
        if (existDict !== null && existDict !== undefined) {
            return existDict;
        }
        return [];
    }

    private static dictsMap: Map<string, any> = new Map<string, any>();

    private static ts: typeof TypeScript;

    private static _genKeyword(methodSignatureName: string): string {
        return methodSignatureName.replace(/([A-Z]+)*([A-Z][a-z])/g, "$1 $2").toLowerCase();
    }

    private static _genInstanceName(str: string): string {
        return str.replace(/(?:^\w|[A-Z]|\b\w)/g, (word, index) => {
            return index === 0 ? word.toLowerCase() : word.toUpperCase();
        });
    }

    private static async _initState() {
        if (!this.ts) {
            this.ts = await getTypescript();
        }
    }

    private static async generatePODictionary(filePath: string) {
        const listMethodDef = [];
        const listLocatorDef = [];
        await this._initState();

        const sourceText = fs.readFileSync(filePath, "utf-8");
        const sourceNode = this.ts.createSourceFile(
            filePath,
            sourceText,
            this.ts.ScriptTarget.Latest,
            true);

        sourceNode.statements.forEach((statement) => {
            if (this.ts.isClassDeclaration(statement) && doesNodeHaveDecorator("page", statement)) {
                const instance = this._genInstanceName(statement.name.text);
                statement.members.forEach((member) => {
                    // generate method dictionary
                    if (this.ts.isMethodDeclaration(member) && doesNodeHaveDecorator("action", member)) {
                        const method = member.name.getText();
                        const des = this.getMethodDecorator(member.decorators);
                        const keyword = des[0];
                        const description = des[1];
                        const args = [];
                        let methodReturn = false;

                        member.parameters.forEach((para) => {
                            const p = { [para.name.getText()]: (para.type ? para.type.getText() : "") };
                            args.push(p);
                        });

                        member.body.statements.forEach((stm) => {
                            // need a better solution ???
                            if (this.ts.isReturnStatement(stm)) {
                                methodReturn = true;
                            }
                        });

                        const methodDef: IActionDef = {
                            keyword,
                            method,
                            instance,
                            description,
                            path: filePath,
                            args,
                            return: methodReturn,
                        };
                        listMethodDef.push(methodDef);
                    }

                    // generate locator dictionary
                    if (this.ts.isPropertyDeclaration(member) && doesNodeHaveDecorator("locator", member)) {

                        const locator = member.name.getText();
                        const locatorDef: ILocatorDef = {
                            instance,
                            locator,
                            path: filePath,
                        };
                        listLocatorDef.push(locatorDef);
                    }
                });
            }
        });
        return [listMethodDef, listLocatorDef];
    }

    private static getMethodDecorator(decorators: TypeScript.NodeArray<TypeScript.Decorator>): string[] {
        const descritions: string[] = [];
        decorators.forEach((deco) => {
            if (this.ts.isCallExpression(deco.expression)) {
                const expression = deco.expression;
                expression.arguments.forEach((arg) => {
                    if (this.ts.isStringLiteral(arg)) {
                        descritions.push(arg.text);
                    }
                });
            }
        });
        return descritions;
    }
}
