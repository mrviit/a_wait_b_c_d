import * as fs from "fs";
import * as TypeScript from "typescript";
import { getTypescript } from "../../libloader";

export let TAB = "  ";
export let util = {
    TAB: 10,
    y: 11,
};

export enum FileType {
    Page = 1,
    Test = 2,
    Native = 3,
}

export function doesNodeHaveDecorator(name: string, node: TypeScript.Node) {
    const deco = node.decorators;
    let result = false;
    if (name === "page" || name === "locator") {
        result = (deco && deco.length === 1 && deco[0].expression.getText() === name);
    } else {
        result = (deco && deco.length === 1 && deco[0].expression.getText().startsWith(`${name}`));
    }
    return result;
}

export async function checkFileType(filePath: string) {
    const ts = await getTypescript();
    const source = ts.createSourceFile(
        filePath,
        fs.readFileSync(filePath).toString(),
        ts.ScriptTarget.Latest,
        true);
    for (const statement of source.statements) {
        if (ts.isClassDeclaration(statement) && doesNodeHaveDecorator("page", statement)) {
            return FileType.Page;
        }
        if (ts.isExpressionStatement(statement) && statement.getText().startsWith("TestModule")) {
            return FileType.Test;
        }
    }
    return FileType.Native;
}
