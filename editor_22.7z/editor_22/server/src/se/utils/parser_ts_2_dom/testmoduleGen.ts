
import * as fs from "fs";
import * as TypeScript from "typescript";
import { ItemType, ITestCase, ITestHook, ITestModule } from "../../common/types";
import { ActionGenerator } from "./actionGen";

export class TestModuleGenerator {

    private model: ITestModule;
    private actGen: ActionGenerator;

    public constructor(private ts: typeof TypeScript) {
        this.actGen = new ActionGenerator(ts);
    }

    public generateTMModel(filePath: string): ITestModule {

        this.initState();

        const source = this.ts.createSourceFile(
            filePath,
            fs.readFileSync(filePath).toString(),
            this.ts.ScriptTarget.Latest, true);

        // visit each node in the root AST
        if (source) {
            this.ts.forEachChild(source, (node) => {
                this.parseNode(node);
            });
        }

        return { ...this.model };
    }

    private initState() {
        this.model = {
            testmodule: "",
            children: [],
            type: ItemType.TestModule,
            usingPOs: [],
        };
    }

    private parseNode(node: TypeScript.Node) {
        switch (node.kind) {
            case this.ts.SyntaxKind.ExpressionStatement:
                this.parseExpression(node);
                break;
            case this.ts.SyntaxKind.ImportDeclaration:
                this.parsePOImport(node as TypeScript.ImportDeclaration);
                break;
            default:
                break;
        }
    }

    private parsePOImport(node: TypeScript.ImportDeclaration) {
        if (this.ts.isImportDeclaration(node) && node.importClause.name) {
            this.model.usingPOs.push({
                name: node.importClause.name.text,
                location: (node.moduleSpecifier as TypeScript.StringLiteral).text,
            });
        }
    }

    private parseExpression(node: TypeScript.Node) {
        if (this.ts.isExpressionStatement(node)) {
            const textNode = node.getText();
            if (textNode.startsWith("TestModule")) {
                this.parseTestModule(node);
            } else if (textNode.startsWith("TestCase")) {
                const testcase = this.parseTestCase(node.expression);
                this.model.children.push(testcase);
            } else if (textNode.startsWith("Before") || textNode.startsWith("After")) {
                const hook = this.parseHook(node.expression);
                this.model.children.push(hook);
            }
        }
    }

    private parseTestModule(node: TypeScript.ExpressionStatement) {
        if (this.ts.isCallExpression(node.expression)) {
            const identify = node.expression.expression.getText();
            const testModuleName = (node.expression.arguments[0] as TypeScript.StringLiteral).text;
            this.model.testmodule = testModuleName;
        }
    }

    private parseTestCase(node: TypeScript.Node) {
        const testCase = {
            testcase: "",
            children: [],
            type: ItemType.TestCase,
        } as ITestCase;

        let tag: any[] = [];
        this.parseTestcaseRecursive(node, tag, testCase);
        if (tag.length > 0) {
            tag = tag.reverse();
            testCase.tags = tag;
        }
        return testCase;
    }

    private parseTestcaseRecursive(node: TypeScript.Node, tag: any[], testCase: ITestCase) {
        if (this.ts.isCallExpression(node)) {
            if (this.ts.isIdentifier(node.expression)) {
                const identify = node.expression.text;
                const testCaseName = (node.arguments[0] as TypeScript.StringLiteral).text;
                const arrowFuntion = (node.arguments[1] as TypeScript.ArrowFunction);
                const arrStatement = this.parseArrowFunction(arrowFuntion);
                testCase.testcase = testCaseName;
                testCase.children.push(...arrStatement);
            } else if (this.ts.isPropertyAccessExpression(node.expression)) {
                tag.push((node.arguments[0] as TypeScript.StringLiteral).text);
                this.parseTestcaseRecursive(node.expression.expression, tag, testCase);
            }
        }
    }

    private parseHook(node: TypeScript.Node) {
        const hook = {
            hook: "",
            children: [],
            type: ItemType.TestHook,
        } as ITestHook;
        // implement ..
        if (this.ts.isCallExpression(node)) {
            const identifier = node.expression as TypeScript.Identifier;
            hook.hook = identifier.text;
            const arrowFunction = (node.arguments[0] as TypeScript.ArrowFunction);
            const arryStatement = this.parseArrowFunction(arrowFunction);
            hook.children.push(...arryStatement);
        }
        return hook;
    }

    private parseArrowFunction(node: TypeScript.ArrowFunction) {
        const arrStatement: object[] = [];
        if (this.ts.isBlock(node.body)) {
            node.body.statements.forEach((state) => {
                arrStatement.push(this.actGen.parseStatement(state));
            });
        }
        return arrStatement;
    }
}
