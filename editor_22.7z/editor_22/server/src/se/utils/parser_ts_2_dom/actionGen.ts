import * as TypeScript from "typescript";
import { IAction, ItemType } from "../../common/types";

export class ActionGenerator {

    constructor(private ts: typeof TypeScript) {
    }

    public parseStatement(node: TypeScript.Node) {
        let action: IAction;
        if (this.ts.isExpressionStatement(node)) {
            const childNode = node.expression;
            if (this.ts.isAwaitExpression(childNode)) {
                const callNode = childNode.expression;
                if (this.ts.isCallExpression(callNode)) {
                    action = this.parseCallExpression(callNode);
                }
            } else if (this.ts.isCallExpression(childNode)) {
                action = this.parseCallExpression(childNode);
            }
        } else if (this.ts.isIfStatement(node)) {
            action = this.parseIfStatement(node);
        } else if (this.ts.isWhileStatement(node)) {
            action = this.parseWhileStatement(node);
        }
        return action;
    }

    private parseIfStatement(node: TypeScript.Node) {
        const action = {} as IAction;
        // implement ...

        return action;
    }

    private parseWhileStatement(node: TypeScript.Node) {
        const action = {} as IAction;
        // implement ...

        return action;
    }

    private parseCallExpression(node: TypeScript.Node) {
        const nodeText = node.getText();
        if (this.ts.isCallExpression(node)) {
            if (nodeText.startsWith("gondola")) {
                return this.parseGondolaExpression(node);
            } else {
                return this.parsePageObjectExpression(node);
            }
        }
    }

    private parseGondolaExpression(node: TypeScript.CallExpression) {
        const action = {
            action: "",
            args: [],
            type: ItemType.Action,
        } as IAction;
        const propertyNode = node.expression;
        if (this.ts.isPropertyAccessExpression(propertyNode)) {
            action.action = propertyNode.name.text;
        }
        action.args = this.parseArguments(node.arguments);
        return action;
    }

    private parsePageObjectExpression(node: TypeScript.CallExpression) {
        const action = {
            action: "",
            args: [],
            type: ItemType.Action,
        } as IAction;
        const propertyNode = node.expression;
        if (this.ts.isPropertyAccessExpression(propertyNode)) {
            action.action = propertyNode.getText();
        }
        action.args = this.parseArguments(node.arguments);
        return action;
    }

    private parseArguments(args: TypeScript.NodeArray<TypeScript.Expression>) {
        const rs = [];
        args.forEach((arg) => {
            let argument: any;
            if (this.ts.isStringLiteral(arg)) {
                argument = arg.text;
            } else if (this.ts.isNumericLiteral(arg)) {
                argument = Number(arg.text);
            } else if (arg.kind === this.ts.SyntaxKind.TrueKeyword) {
                argument = true;
            } else if (arg.kind === this.ts.SyntaxKind.FalseKeyword) {
                argument = false;
            } else if (this.ts.isIdentifier(arg)) {
                argument = `$${arg.text}`;
            } else if (this.ts.isPrefixUnaryExpression(arg)) {
                argument = arg.getText();
            } else if (this.ts.isPropertyAccessExpression(arg)) {
                argument = `$${arg.getText()}`;
            } else if (this.ts.isObjectLiteralExpression(arg)) {
                argument = `$${arg.getText()}`;
            }
            rs.push(argument);
        });
        return rs;
    }
}
