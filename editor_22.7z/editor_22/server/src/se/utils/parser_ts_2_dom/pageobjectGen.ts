import * as fs from "fs";
import * as TypeScript from "typescript";
import { IAction, ILocator, IMethod, IPageObject, IParameter } from "../../common/types";
import { doesNodeHaveDecorator } from "../util";
import { ActionGenerator } from "./actionGen";

export class POGenerator {

    private model: IPageObject;
    private actGen: ActionGenerator;

    public constructor(private ts: typeof TypeScript) {
        this.actGen = new ActionGenerator(ts);
    }

    public generatePOModel(filePath: string): IPageObject {
        this.resetModel();
        const source = this.ts.createSourceFile(
            filePath,
            fs.readFileSync(filePath).toString(),
            this.ts.ScriptTarget.Latest,
            true);
        if (source) {
            this.ts.forEachChild(source, (node) => {
                this.parseNode(node);
            });
        }
        return { ...this.model };
    }

    private resetModel() {
        this.model = {
            pageobject: "",
            children: [],
        };
    }

    private parseNode(node: TypeScript.Node): any {
        switch (node.kind) {
            case this.ts.SyntaxKind.ClassDeclaration:
                this.parseClassDeclare(node);
                break;
            default:
                break;
        }
    }

    private parseClassDeclare(node: TypeScript.Node) {
        const deco = node.decorators;

        if (this.ts.isClassDeclaration(node) && doesNodeHaveDecorator("page", node)) {
            this.model.pageobject = node.name.text;
            const locators = {
                locators: "",
                children: [],
            };
            const methods = {
                methods: "",
                children: [],
            };

            node.members.forEach((member: TypeScript.ClassElement) => {
                if (this.ts.isPropertyDeclaration(member) && doesNodeHaveDecorator("locator", member)) {
                    locators.children.push(this.parseLocator(member));
                }

                if (this.ts.isMethodDeclaration(member) && doesNodeHaveDecorator("action", member)) {
                    methods.children.push(this.parseMethod(member));
                }
            });
            this.model.children.push(locators);
            this.model.children.push(methods);
        }
    }

    private parseMethod(member: TypeScript.MethodDeclaration) {
        const method: IMethod = {
            method: "",
            des: [],
            params: [],
            children: [],
        };
        method.method = member.name.getText();
        method.des.push(...this.parseMethodDecorator(member.decorators));
        method.params.push(...this.parseMethodParams(member.parameters));
        method.children.push(...this.parseMethodBody(member.body, method));
        return method;
    }

    private parseMethodDecorator(decorators: TypeScript.NodeArray<TypeScript.Decorator>): string[] {
        const descritions: string[] = [];
        decorators.forEach((deco) => {
            if (this.ts.isCallExpression(deco.expression)) {
                const expression = deco.expression;
                expression.arguments.forEach((arg) => {
                    if (this.ts.isStringLiteral(arg)) {
                        descritions.push(arg.text);
                    }
                });
            }
        });
        return descritions;
    }

    private parseMethodBody(body: TypeScript.Block, method: IMethod) {
        const lstAction: IAction[] = [];
        body.statements.forEach((state) => {
            if (!this.ts.isReturnStatement(state)) {
                lstAction.push(this.actGen.parseStatement(state));
            } else {
                method.return = this.parseExpressionValue(state.expression);
            }
        });
        return lstAction;
    }

    private parseMethodParams(parameters: TypeScript.NodeArray<TypeScript.ParameterDeclaration>): IParameter[] {
        const params: IParameter[] = [];
        parameters.forEach((param: TypeScript.ParameterDeclaration) => {
            const paraObj: IParameter = {
                name: "",
                type: "",
            };
            paraObj.name = param.name.getText();
            if (param.type) {
                paraObj.type = this.getTypeMethodParameter(param.type);
            }
            if (param.initializer) {
                paraObj.default = this.parseExpressionValue(param.initializer);
            }
            params.push(paraObj);
        });
        return params;
    }

    private parseExpressionValue(node: TypeScript.Expression) {
        let value: any;
        if (this.ts.isStringLiteral(node)) {
            value = node.text;
        } else if (this.ts.isNumericLiteral(node)) {
            value = Number(node.text);
        } else if (node.kind === this.ts.SyntaxKind.TrueKeyword) {
            value = true;
        } else if (node.kind === this.ts.SyntaxKind.FalseKeyword) {
            value = false;
        } else if (this.ts.isIdentifier(node)) {
            value = `$${node.text}`;
        } else if (this.ts.isPrefixUnaryExpression(node)) {
            value = node.getText();
        } else if (this.ts.isPropertyAccessExpression(node)) {
            value = `$${node.getText()}`;
        }
        return value;
    }

    private getTypeMethodParameter(typeNode: TypeScript.TypeNode): string {
        let type: string;
        switch (typeNode.kind) {
            case this.ts.SyntaxKind.StringKeyword:
                type = "string";
                break;
            case this.ts.SyntaxKind.NumberKeyword:
                type = "number";
                break;
            case this.ts.SyntaxKind.BooleanKeyword:
                type = "boolean";
                break;
            case this.ts.SyntaxKind.AnyKeyword:
                type = "any";
                break;
            // handle for another kind as object ..
            default:
                break;
        }
        return type;
    }

    private parseLocator(member: TypeScript.PropertyDeclaration): ILocator {
        const locator: ILocator = {
            name: "",
            value: null,
        };
        locator.name = member.name.getText();
        locator.value = this.getValueLocator(member.initializer);
        return locator;
    }

    private getValueLocator(value: TypeScript.Expression): any {
        let locatorValue: any;
        if (this.ts.isStringLiteral(value)) {
            locatorValue = value.text;
        } else if (this.ts.isObjectLiteralExpression(value)) {
            locatorValue = `$${value.getText()}`;
        }
        // handle for another type...
        return locatorValue;
    }
}
