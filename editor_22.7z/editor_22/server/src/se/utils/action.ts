interface IArg {
    [key: string]: string;
}

interface IActionDef {
    keyword: string;
    method: string;
    instance?: string;
    description?: string;
    path?: string;
    args?: IArg[];
}

export const actionDict: IActionDef[] = [
    {
        method: "checkEqual",
        args: [
            {
                "actual": "T"
            },
            {
                "expected": "T"
            },
            {
                "message": "string"
            }
        ],
        keyword: "check equal",
        instance: "gondola",
        description: "Tests for deep equality between the actual and expected parameters."
    },
    {
        method: "checkNotEqual",
        args: [
            {
                "actual": "T"
            },
            {
                "expected": "T"
            },
            {
                "message": "string"
            }
        ],
        keyword: "check not equal",
        instance: "gondola",
        description: "Tests for deep strict inequality"
    },
    {
        method: "click",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "context": "string"
            }
        ],
        keyword: "click",
        instance: "gondola",
        description: "Perform a click on a link or a button, given by a locator."
    },
    {
        method: "clickPopup",
        args: [
            {
                "option": "string"
            }
        ],
        keyword: "click popup",
        instance: "gondola",
        description: "Click on the active JavaScript native popup window, as created by window.alert|window.confirm|window.prompt."
    },
    {
        method: "closeCurrentTab",
        args: [],
        keyword: "close current tab",
        instance: "gondola",
        description: "Close current tab"
    },
    {
        method: "closeOtherTabs",
        args: [],
        keyword: "close other tabs",
        instance: "gondola",
        description: "Close all tabs except for the current one."
    },
    {
        method: "checkControlExist",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "check control exist",
        instance: "gondola",
        description: "Check for the existence of a control. Result is Passed if the specified control is found; otherwise Failed."
    },
    {
        method: "checkControlNotExist",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "check control not exist",
        instance: "gondola",
        description: "Check for the nonexistence of a control.\r\nResult is Passed if the specified control is not found; otherwise Failed."
    },
    {
        method: "checkControlProperty",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "property": "string"
            },
            {
                "value": "string"
            }
        ],
        keyword: "check control property",
        instance: "gondola",
        description: "Checks first element with given locator have given attribute.\r\nResult is Passed if the values match; otherwise Failed."
    },
    {
        method: "checkWindowExist",
        args: [
            {
                "title": "string"
            }
        ],
        keyword: "check window exist",
        instance: "gondola",
        description: "Checks that title is equal to provided one."
    },
    {
        method: "getElementCount",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "get element count",
        instance: "gondola",
        description: "Count visible Elements."
    },
    {
        method: "getText",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "get text",
        instance: "gondola",
        description: "Retrieves a text from the located element."
    },
    {
        method: "checkText",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "value": "string"
            }
        ],
        keyword: "check text",
        instance: "gondola",
        description: "Check text from the located element with given value."
    },
    {
        method: "deleteCookie",
        args: [
            {
                "cookie": "string"
            }
        ],
        keyword: "delete cookie",
        instance: "gondola",
        description: "Clears all cookies."
    },
    {
        method: "doesControlExist",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "does control exist",
        instance: "gondola",
        description: "Return a Boolean value to indicate whether the specified control is found to exist.\r\nReturned Boolean value is 1 if control is found.Otherwise return 0"
    },
    {
        method: "enter",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "value": "string"
            }
        ],
        keyword: "enter",
        instance: "gondola",
        description: "Fills a text field or textarea, after clearing its value, with the given string."
    },
    {
        method: "executeScript",
        args: [
            {
                "fn": "Function"
            }
        ],
        keyword: "execute script",
        instance: "gondola",
        description: "Executes sync script on a page. Pass arguments to function as additional parameters.\r\nWill return execution result to a test. In this case you should use async function\r\nand await to receive results."
    },
    {
        method: "get",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "get",
        instance: "gondola",
        description: "Retrieves a value from the located element and returns it to test."
    },
    {
        method: "getControlProperty",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "attr": "string"
            }
        ],
        keyword: "get control property",
        instance: "gondola",
        description: "Retrieves an attribute from the first located element."
    },
    {
        method: "getElementsAttribute",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "attr": "string"
            }
        ],
        keyword: "get elements attribute",
        instance: "gondola",
        description: "Retrieves an attribute from the all located elements."
    },
    {
        method: "getSelectedItems",
        args: [
            {
                "selectLocator": "string | ILocator"
            }
        ],
        keyword: "get selected items",
        instance: "gondola",
        description: "Get selected items in list box or combo box that defined by html select tag"
    },
    {
        method: "getPopupText",
        args: [],
        keyword: "get popup text",
        instance: "gondola",
        description: "get the text within the popup, as created by window.alert|window.confirm|window.prompt.\r\nIf no popup is visible then it will return null"
    },
    {
        method: "navigate",
        args: [
            {
                "url": "string"
            }
        ],
        keyword: "navigate",
        instance: "gondola",
        description: "Opens a web page in a browser.\r\nRequires relative or absolute url.\r\nIf url starts with /, opens a web page of a site defined in url config parameter."
    },
    {
        method: "maximize",
        args: [],
        keyword: "maximize",
        instance: "gondola",
        description: "Maximize the current window."
    },
    {
        method: "openNewTab",
        args: [],
        keyword: "open new tab",
        instance: "gondola",
        description: "Open new tab and switch to it."
    },
    {
        method: "refresh",
        args: [],
        keyword: "refresh",
        instance: "gondola",
        description: "Reloads the current page."
    },
    {
        method: "report",
        args: [
            {
                "describle": "string"
            },
            {
                "imagepath": "string"
            }
        ],
        keyword: "report",
        instance: "gondola",
        description: "Create a report using mochawesome."
    },
    {
        method: "saveScreenshot",
        args: [
            {
                "fileName": "string"
            },
            {
                "fullPage": "boolean"
            }
        ],
        keyword: "save screenshot",
        instance: "gondola",
        description: "Saves a screenshot to ouput folder (set in gondola.json)"
    },
    {
        method: "select",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "items": "string | string[]"
            }
        ],
        keyword: "select",
        instance: "gondola",
        description: "Select items in list box or combo box that defined by html select tag"
    },
    {
        method: "setErrorHandler",
        args: [
            {
                "callback": "(errorInfo: IErrorInfo, actor: any) => void"
            }
        ],
        keyword: "set error handler",
        instance: "gondola",
        description: "Callback the [callback] when error happens"
    },
    {
        method: "setPopupText",
        args: [
            {
                "value": "string"
            }
        ],
        keyword: "set popup text",
        instance: "gondola",
        description: "set text into prompt popup."
    },
    {
        method: "setState",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "value": "boolean"
            }
        ],
        keyword: "set state",
        instance: "gondola",
        description: "Set state for the located checkbox/radio."
    },
    {
        method: "switchFrame",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "switch frame",
        instance: "gondola",
        description: "Switches frame or in case of null locator reverts to parent."
    },
    {
        method: "switchBrowserTab",
        args: [
            {
                "option": "string"
            },
            {
                "num": "number"
            }
        ],
        keyword: "switch browser tab",
        instance: "gondola",
        description: "switch focus to a particular tab by its number. It waits tabs loading and then switch tab"
    },
    {
        method: "wait",
        args: [
            {
                "sec": "number"
            }
        ],
        keyword: "wait",
        instance: "gondola",
        description: "Pauses execution for a number of seconds."
    },
    {
        method: "waitForElement",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "sec": "number"
            }
        ],
        keyword: "wait for element",
        instance: "gondola",
        description: "Waits for element to be present on page (by default waits for 1sec)."
    },
    {
        method: "waitForDisappear",
        args: [
            {
                "locator": "string | ILocator"
            },
            {
                "sec": "number"
            }
        ],
        keyword: "wait for disappear",
        instance: "gondola",
        description: "Waits for an element to become not attached to the DOM on a page (by default waits for 1sec)."
    },
    {
        method: "getJSONValue",
        args: [
            {
                "jsonObject": "any"
            },
            {
                "jsonPath": "string"
            }
        ],
        keyword: "getjson value",
        instance: "gondola",
        description: "get JSON value with JSON path"
    },
    {
        method: "checkJSONValue",
        args: [
            {
                "jsonObject": "any"
            },
            {
                "jsonPath": "string"
            },
            {
                "expected": "any"
            }
        ],
        keyword: "checkjson value",
        instance: "gondola",
        description: "check JSON value by JSON path"
    },
    {
        method: "tap",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "tap",
        instance: "gondola",
        description: "Taps on a mobile element"
    },
    {
        method: "runOnAndroid",
        args: [
            {
                "options": "any"
            },
            {
                "fn": "Function"
            }
        ],
        keyword: "run on android",
        instance: "gondola",
        description: "Runs the given function while testing Android\r\n\r\nNote: in case use options capabilities, remember that action only work if\r\nthis option is declared in the gondola config file."
    },
    {
        method: "runOnIOS",
        args: [
            {
                "options": "any"
            },
            {
                "fn": "Function"
            }
        ],
        keyword: "run onios",
        instance: "gondola",
        description: "Runs the given function while testing iOS\r\n\r\nNote: in case use options capabilities, remember that action only work if\r\nthis option is declared in the gondola config file."
    },
    {
        method: "checkAppIsInstalled",
        args: [
            {
                "appPackageId": "string"
            }
        ],
        keyword: "check app is installed",
        instance: "gondola",
        description: "Checks that expected App is installed already"
    },
    {
        method: "switchDevice",
        args: [
            {
                "deviceName": "string"
            }
        ],
        keyword: "switch device",
        instance: "gondola",
        description: "Changes the run context to given deviceName\r\nTo get actions run parallel on all devices again, use {@link runOnAllDevices}.\r\n\r\n**LIMITATION:** Currently, user must await all actions on specific device be done\r\nbefore switching to other."
    },
    {
        method: "runOnAllDevices",
        args: [],
        keyword: "run on all devices",
        instance: "gondola",
        description: "Gets followed actions run parallel\r\n\r\n**LIMITATION:** Currently, user must await all actions be done\r\nbefore switching device."
    },
    {
        method: "getCurrentBrowser",
        args: [],
        keyword: "get current browser",
        instance: "gondola",
        description: "Gets the WebDriver browser"
    },
    {
        method: "sendDeviceKeyEvent",
        args: [
            {
                "keyValue": "string | number"
            }
        ],
        keyword: "send device key event",
        instance: "gondola",
        description: "Sends a key event to the device."
    },
    {
        method: "getElementBounds",
        args: [
            {
                "element": "string | ILocator"
            }
        ],
        keyword: "get element bounds",
        instance: "gondola",
        description: "Retrieve element's boundary"
    },
    {
        method: "swipe",
        args: [
            {
                "element": "string | ILocator"
            },
            {
                "offsetX": "number"
            },
            {
                "offsetY": "number"
            }
        ],
        keyword: "swipe",
        instance: "gondola",
        description: "Perform a swipe on an element."
    },
    {
        method: "swipeByCoordinates",
        args: [
            {
                "startX": "number"
            },
            {
                "startY": "number"
            },
            {
                "offsetX": "number"
            },
            {
                "offsetY": "number"
            }
        ],
        keyword: "swipe by coordinates",
        instance: "gondola",
        description: "Perform a swipe on the screen."
    },
    {
        method: "setRequestTimeout",
        args: [
            {
                "newTimeout": "number"
            }
        ],
        keyword: "set request timeout",
        instance: "gondola",
        description: "Sets timeout for the request"
    },
    {
        method: "sendGetRequest",
        args: [
            {
                "url": "string"
            },
            {
                "headers": "{}"
            }
        ],
        keyword: "send get request",
        instance: "gondola",
        description: "Sends GET request"
    },
    {
        method: "sendPostRequest",
        args: [
            {
                "url": "string"
            },
            {
                "payload": "{}"
            },
            {
                "headers": "{}"
            }
        ],
        keyword: "send post request",
        instance: "gondola",
        description: "Sends POST request"
    },
    {
        method: "sendPatchRequest",
        args: [
            {
                "url": "string"
            },
            {
                "payload": "{}"
            },
            {
                "headers": "{}"
            }
        ],
        keyword: "send patch request",
        instance: "gondola",
        description: "Sends PATCH request"
    },
    {
        method: "sendPutRequest",
        args: [
            {
                "url": "string"
            },
            {
                "payload": "{}"
            },
            {
                "headers": "{}"
            }
        ],
        keyword: "send put request",
        instance: "gondola",
        description: "Sends PUT request"
    },
    {
        method: "sendDeleteRequest",
        args: [
            {
                "url": "string"
            },
            {
                "headers": "{}"
            }
        ],
        keyword: "send delete request",
        instance: "gondola",
        description: "Sends DELETE request"
    },
    {
        method: "checkResponseStatus",
        args: [
            {
                "response": "any"
            },
            {
                "expected": "number"
            }
        ],
        keyword: "check response status",
        instance: "gondola",
        description: "parse response data"
    },
    {
        method: "seeVisualDiff",
        args: [
            {
                "baseImage": "string"
            },
            {
                "options": "any"
            }
        ],
        keyword: "see visual diff",
        instance: "gondola",
        description: "Check Visual Difference for Base and Screenshot Image"
    },
    {
        method: "seeVisualDiffForElement",
        args: [
            {
                "selector": "string | ILocator"
            },
            {
                "baseImage": "string"
            },
            {
                "options": "any"
            }
        ],
        keyword: "see visual diff for element",
        instance: "gondola",
        description: "See Visual Diff for an Element on a Page"
    },
    {
        method: "unknown",
        keyword: "unknown",
        instance: "gondola",
        path: "",
        description: "this is unknown action",
        args: [
            { arg1: "string" },
            { arg2: "string" },
            { arg3: "string" },
            { arg4: "string" },
            { arg5: "string" },
        ],
    },
];
