import { EmitHint, NewLineKind, ScriptKind} from "typescript";

// NOTICE THAT: this is a dev dependency only. do not use directly
import * as TypeScript from "typescript";

/**
 * Options for printing a node.
 */
export interface PrintNodeOptions {
    /**
     * Whether to remove comments or not.
     */
    removeComments?: boolean;
    /**
     * New line kind.
     *
     * Defaults to line feed.
     */
    newLineKind?: NewLineKind;
    /**
     * From the compiler api: "A value indicating the purpose of a node. This is primarily used to
     * distinguish between an `Identifier` used in an expression position, versus an
     * `Identifier` used as an `IdentifierName` as part of a declaration. For most nodes you
     * should just pass `Unspecified`."
     *
     * Defaults to `Unspecified`.
     */
    emitHint?: EmitHint;
    /**
     * The script kind.
     *
     * @remarks This is only useful when passing in a compiler node that was constructed
     * with the compiler API factory methods.
     *
     * Defaults to TSX.
     */
    scriptKind?: ScriptKind;
}

/**
 * Prints the provided node using the compiler's printer.
 * @param node - Compiler node.
 * @param options - Options.
 * @remarks If the node was not constructed with the compiler API factory methods and the node
 * does not have parents set, then use the other overload that accepts a source file.
 */
export function printNode(library: typeof TypeScript, node: TypeScript.Node, options?: PrintNodeOptions): string;
/**
 * Prints the provided node using the compiler's printer.
 * @param node - Compiler node.
 * @param sourceFile - Compiler source file.
 * @param options - Options.
 */
export function printNode( library: typeof TypeScript,
                           node: TypeScript.Node,
                           sourceFile: TypeScript.SourceFile,
                           options?: PrintNodeOptions): string;
export function printNode( library: typeof TypeScript,
                           node: TypeScript.Node,
                           sourceFileOrOptions?: PrintNodeOptions | TypeScript.SourceFile,
                           secondOverloadOptions?: PrintNodeOptions) {
    const ts = library;
    const isFirstOverload = !sourceFileOrOptions ||
                            (sourceFileOrOptions as TypeScript.SourceFile).kind !== ts.SyntaxKind.SourceFile;
    const options = getOptions();
    const sourceFile = getSourceFile();

    const printer = ts.createPrinter({
        newLine: !options.newLineKind ? ts.NewLineKind.LineFeed : options.newLineKind,
        removeComments: options.removeComments || false ,
    });

    if (!sourceFile ) {
        return printer.printFile(node as TypeScript.SourceFile);
    } else {
        return printer.printNode( !options.emitHint ? ts.EmitHint.Unspecified : options.emitHint, node, sourceFile);
    }

    function getSourceFile() {
        if (isFirstOverload) {
            if (node.kind === ts.SyntaxKind.SourceFile) {
                return undefined;
            }
            const topParent = getNodeSourceFile();
            if (topParent == null) {
                // create a result file (see https://github.com/Microsoft/TypeScript/wiki/Using-the-Compiler-API)
                const scriptKind = getScriptKind();
                return ts.createSourceFile(`print.${getFileExt(scriptKind)}`,
                            "", ts.ScriptTarget.Latest, false, scriptKind);
            }
            return topParent;
        }

        return sourceFileOrOptions as TypeScript.SourceFile;

        function getScriptKind() {
            return options.scriptKind == null ? ts.ScriptKind.TSX : options.scriptKind;
        }

        function getFileExt(scriptKind: ScriptKind) {
            if (scriptKind === ts.ScriptKind.JSX || scriptKind === ts.ScriptKind.TSX) {
                return "tsx";
            }
            return "ts";
        }
    }

    function getNodeSourceFile() {
        let topNode: TypeScript.Node | undefined = node.parent;
        while (topNode != null && topNode.parent != null) {
            topNode = topNode.parent;
        }
        return topNode as TypeScript.SourceFile;
    }

    function getOptions() {
        return (isFirstOverload ? sourceFileOrOptions as PrintNodeOptions : secondOverloadOptions) || {};
    }
}
