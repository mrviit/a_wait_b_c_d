import { IComment } from "../../common/types";
import { TAB } from "../util";

class CommentParser {
    public parseComment(obj: IComment) {
        let statement = "";
        statement += "\n".repeat(obj.offset);
        if (obj.comment) {
            statement += `${TAB}// ${obj.comment}\n`;
        }
        return statement;
    }
}
export default new CommentParser();
