import * as TypeScript from "typescript"; // NOTICE THAT: this is a dev dependency only. do not use directly
import { ITestHook } from "../../common/types";
import {ActionParser} from "./actionParser";

export class HookParser {

    private actParser: ActionParser;
    public constructor(private ts: typeof TypeScript) {
        this.actParser = new ActionParser(ts);
    }

    public parseEventHook(hookObj: ITestHook) {

        const hookType = hookObj.hook;

        const statement: TypeScript.Statement[] = [];
        const lstStatement = hookObj.children;
        statement.push(this.createHook(hookType, lstStatement));
        return statement;
    }

    private createHook(hookType: string, listStatement: object[]) {
        return this.ts.createExpressionStatement(
            this.ts.createCall(this.ts.createIdentifier(hookType), undefined, [
                this.ts.createArrowFunction(
                    [this.ts.createModifier( this.ts.SyntaxKind.AsyncKeyword)],
                    undefined,
                    [],
                    undefined,
                    this.ts.createToken(this.ts.SyntaxKind.EqualsGreaterThanToken),
                    this.actParser.createBlockStatement(listStatement),
                ),
            ]),
        );
    }
}
