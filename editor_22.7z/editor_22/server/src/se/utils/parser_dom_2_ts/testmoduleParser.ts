import * as TypeScript from "typescript"; // NOTICE THAT: this is a dev dependency only. do not use directly
import { ITestCase, ITestHook, ITestModule, IPageObject, IPageObjectInfo } from "../../common/types";
import { HookParser } from "./hookParser";
import { TestcaseParser } from "./testcaseParser";

export class TestModuleParser {

    private bParser: HookParser;
    private tcParser: TestcaseParser;

    public constructor(private ts: typeof TypeScript) {
        this.bParser = new HookParser(ts);
        this.tcParser = new TestcaseParser(ts);
    }

    public parseTestModule(moduleObj: ITestModule) {
        const statements: TypeScript.Statement[] = [];

        // TestModule("name").tag("tag")
        statements.push(this.createImport());
        for (const po of moduleObj.usingPOs) {
            statements.push(this.createPageObjectImport(po));
        }

        statements.push(this.createTestModule(moduleObj.testmodule, moduleObj.tags));

        // parse the rest of test-module
        const children = moduleObj.children;
        children.forEach((child) => {
            // parse Before component
            if (child.hasOwnProperty("hook")) {
                const hookObj = child as ITestHook;
                statements.push(...this.bParser.parseEventHook(hookObj));
            }

            // parse Testcase component
            if (child.hasOwnProperty("testcase")) {
                const testcaseObj = child as ITestCase;
                statements.push(...this.tcParser.parseTestCase(testcaseObj));
            }
        });
        return statements;
    }

    private createImport() {
        return this.ts.createImportDeclaration(
            undefined,
            undefined,
            this.ts.createImportClause(
                undefined,
                this.ts.createNamedImports([
                    this.ts.createImportSpecifier(
                        undefined,
                        this.ts.createIdentifier("TestModule"),
                    ),
                    this.ts.createImportSpecifier(undefined, this.ts.createIdentifier("TestCase")),
                    this.ts.createImportSpecifier(undefined, this.ts.createIdentifier("gondola")),
                ]),
            ),
            this.ts.createStringLiteral("gondolajs"),
        );
    }

    private createPageObjectImport(po: IPageObjectInfo) {
        return this.ts.createImportDeclaration(
            undefined,
            undefined,
            this.ts.createImportClause(
                this.ts.createIdentifier(po.name),
                undefined,
            ),
            this.ts.createStringLiteral(po.location),
        );
    }

    private createTestModule(name: string, tags?: string[]) {
        if (tags) {
            tags = tags.reverse();
        }
        const callExpress = this.createTMCallExpression(name, tags);
        const expressionStatement = this.ts.createExpressionStatement(callExpress);
        return expressionStatement;
    }

    private createTMCallExpression(name: string, arr?: string[]) {
        if (!arr) {
            return this.ts.createCall(this.ts.createIdentifier("TestModule"), undefined, [
                this.ts.createStringLiteral(name),
            ]);
        }

        if (arr.length > 1) {
            const next = arr.splice(0, 1);
            const childexress = this.createTMCallExpression(name, arr);
            const st = this.ts.createCall(this.ts.createPropertyAccess(childexress, this.ts.createIdentifier("tag")),
                undefined,
                [this.ts.createStringLiteral(next[0])],
            );
            return st;
        } else {
            return this.ts.createCall(
                this.ts.createPropertyAccess(
                    this.ts.createCall(this.ts.createIdentifier("TestModule"), undefined, [
                        this.ts.createStringLiteral(name),
                    ]),
                    this.ts.createIdentifier("tag"),
                ),
                undefined,
                [this.ts.createStringLiteral(arr[0])],
            );

        }
    }
}
