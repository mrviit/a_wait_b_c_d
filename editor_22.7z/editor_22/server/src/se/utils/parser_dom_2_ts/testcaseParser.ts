
import * as TypeScript from "typescript"; // NOTICE THAT: this is a dev dependency only. do not use directly
import { ITestCase } from "../../common/types";
import {ActionParser} from "./actionParser";

export class TestcaseParser {

    private actParser: ActionParser;
    public constructor(private ts: typeof TypeScript) {
        this.actParser = new ActionParser(ts);
    }

    public parseTestCase(obj: ITestCase) {
        const statement: TypeScript.Statement[] = [];
        statement.push(this.createTestCase(obj.testcase, obj.children, obj.tags));
        return statement;
    }

    private createTestCase(name: string, lstStatement: object[], tags?: string[]) {
        if (tags) {
            tags = tags.reverse();
        }
        const callExpress = this.createTCCallExpression(name, lstStatement, tags);
        const expressionStatement = this.ts.createExpressionStatement(callExpress);
        return expressionStatement;
    }

    private createTCCallExpression(name: string, lstStatement: object[], arr?: string[]) {
        if (!arr) {
            return this.ts.createCall(this.ts.createIdentifier("TestCase"), undefined, [
                this.ts.createStringLiteral(name),
                this.ts.createArrowFunction(
                    [this.ts.createModifier(this.ts.SyntaxKind.AsyncKeyword)],
                    undefined,
                    [],
                    undefined,
                    this.ts.createToken(this.ts.SyntaxKind.EqualsGreaterThanToken),
                    this.actParser.createBlockStatement(lstStatement),
                ),
            ]);
        }

        if (arr.length > 1) {
            const next = arr.splice(0, 1);
            const childexress = this.createTCCallExpression(name, lstStatement, arr);
            const st = this.ts.createCall(this.ts.createPropertyAccess(childexress, this.ts.createIdentifier("tag")),
                undefined,
                [this.ts.createStringLiteral(next[0])],
            );
            return st;
        } else {
            return this.ts.createCall(
                this.ts.createPropertyAccess(
                    this.ts.createCall(this.ts.createIdentifier("TestCase"), undefined, [
                        this.ts.createStringLiteral(name),
                        this.ts.createArrowFunction(
                            [this.ts.createModifier(this.ts.SyntaxKind.AsyncKeyword)],
                            undefined,
                            [],
                            undefined,
                            this.ts.createToken(this.ts.SyntaxKind.EqualsGreaterThanToken),
                            this.actParser.createBlockStatement(lstStatement),
                        ),
                    ]),
                    this.ts.createIdentifier("tag"),
                ),
                undefined,
                [this.ts.createStringLiteral(arr[0])],
            );
        }
    }
}
