import * as TypeScript from "typescript"; // NOTICE THAT: this is a dev dependency only. do not use directly
import { IAction } from "../../common/types";

export class ActionParser {

    constructor(private ts: typeof TypeScript) {
    }

    public createListStatement(lstStatement: object[]) {
        const arr: TypeScript.Statement[] = [];
        lstStatement.forEach((statement, index) => {
            if (statement.hasOwnProperty("action")) {

                // const actObj = statement as IAction;
                const actObj = this.parseToActionObj(statement) as IAction;
                arr.push(this.parseAction(actObj));
            }
        });
        return arr;
    }

    public createBlockStatement(lstStatement: object[]) {
        const arr: TypeScript.Statement[] = [];
        lstStatement.forEach((statement) => {
            if (statement.hasOwnProperty("action")) {
                // const actObj = statement as IAction;
                const actObj = this.parseToActionObj(statement) as IAction;
                arr.push(this.parseAction(actObj));
            }
        });
        return this.ts.createBlock(arr, true);
    }

    private parseAction(obj: IAction) {
        let statement: TypeScript.Statement;

        const action = obj.action;

        if (action === "if") {
            const ifObj = obj as IAction;
            const condition = ifObj.args[0][1].condition as string;
            const thenStatement = ifObj.args[0][2].work;

            let elseStatement;
            if (ifObj.args[1] && ifObj.args[1][1]) {
                elseStatement = ifObj.args[1][1].work;
            }
            statement = this.createIfAction(condition, thenStatement, elseStatement);
        } else if (action === "while") {
            const whileObj = obj as IAction;
            const condition = whileObj.args[0].condition as string;
            const block = whileObj.args[1].work;
            statement = this.createWhileAction(condition, block);
        } else {
            // use a map action to convert from abt to typescript
            const actionName = action;
            const actionArgs = obj.args;
            const isAwait = true;

            statement = this.createAction(actionName, actionArgs, isAwait);
        }
        return statement;
    }

    private parseToActionObj(statement: any) {
        const result = {} as IAction;
        result.action = statement.action;
        result.args = [];
        statement.args.forEach((value: any) => {
            result.args.push({ key: value });
        });
        return result;
    }

    private createAction(actionName: string, actionArgs: object[], isAwait?: boolean): TypeScript.ExpressionStatement {
        const argArr: TypeScript.Expression[] = [];
        let index = 0;
        while (index < actionArgs.length) {
            const val = Object.values(actionArgs[index])[0];
            const type = typeof val;
            if (type === "string") {
                if (val.startsWith("$")) {
                    argArr.push(this.ts.createIdentifier(val.substr(1)));
                } else {
                    argArr.push(this.ts.createStringLiteral(val));
                }
            } else if (type === "number") {
                argArr.push(this.ts.createNumericLiteral(String(val)));
            } else if (type === "boolean") {
                if (val === true) {
                    argArr.push(this.ts.createTrue());
                } else {
                    argArr.push(this.ts.createFalse());
                }
            }
            index += 1;
        }

        let result;
        if (!isAwait) {
            result = this.ts.createExpressionStatement(
                this.ts.createCall(
                    this.ts.createPropertyAccess(
                        this.ts.createIdentifier("gondola"),
                        this.ts.createIdentifier(actionName),
                    ),
                    undefined,
                    argArr,
                ),
            );
        } else {
            result = this.ts.createExpressionStatement(
                this.ts.createAwait(
                    this.ts.createCall(
                        actionName.includes(".") ?
                            this.ts.createIdentifier(actionName) :
                            this.ts.createIdentifier("gondola." + actionName),
                        undefined,
                        argArr,
                    ),
                ),
            );
        }

        return result;
    }

    private createIfAction(condition: string, thenStatement: object[], elseStatement?: object[]) {
        let statement: TypeScript.Statement;
        const conditionStatement = this.createConditionExpression(condition);
        const thenBlock = this.createBlockStatement(thenStatement);
        if (elseStatement) {
            const elseBlock = this.createBlockStatement(elseStatement);
            statement = this.ts.createIf(conditionStatement, thenBlock, elseBlock);
        } else {
            statement = this.ts.createIf(conditionStatement, thenBlock);
        }
        return statement;
    }

    // this solution is not correct in some cases condition have number
    // temporate use this as work arround.
    private createConditionExpression(condition: string) {
        /*
        const prj = new Project();
        condition = condition.replace("$", "");
        const sourceFile = prj.createSourceFile("temp.ts", condition);
        const rs = sourceFile.compilerNode.statements[0] as TypeScript.ExpressionStatement;
        return rs.expression;
        */
        return undefined;
    }

    private createWhileAction(condition: string, blockStatement: object[]) {
        const conditionStatement = this.createConditionExpression(condition);
        const block = this.createBlockStatement(blockStatement);
        return this.ts.createWhile(conditionStatement, block);
    }
}
