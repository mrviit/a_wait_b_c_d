import * as TypeScript from "typescript"; // NOTICE THAT: this is a dev dependency only. do not use directly
import { ILocator, IMethod, IPageObject, IParameter } from "../../common/types";
import { ActionParser } from "./actionParser";
export class PageObjectParser {
    private actParser: ActionParser;
    public constructor(private ts: typeof TypeScript) {
        this.actParser = new ActionParser(ts);
    }

    public parsePageObject(poObject: IPageObject) {
        const statement: TypeScript.Statement[] = [];
        statement.push(this.createImport());
        statement.push(this.createPageObject(poObject));
        statement.push(this.createExport(poObject));
        return statement;
    }

    private createImport(): TypeScript.Statement {
        return this.ts.createImportDeclaration(
            undefined,
            undefined,
            this.ts.createImportClause(
                undefined,
                this.ts.createNamedImports([
                    this.ts.createImportSpecifier(undefined, this.ts.createIdentifier("action")),
                    this.ts.createImportSpecifier(undefined, this.ts.createIdentifier("gondola")),
                    this.ts.createImportSpecifier(undefined, this.ts.createIdentifier("locator")),
                    this.ts.createImportSpecifier(undefined, this.ts.createIdentifier("page")),
                ]),
            ),
            this.ts.createStringLiteral("gondolajs"),
        );
    }

    private createExport(poObject: IPageObject): TypeScript.Statement {
        return this.ts.createExportAssignment(
            undefined,
            undefined,
            undefined,
            this.ts.createNew(this.ts.createIdentifier(poObject.pageobject), undefined, []),
        );
    }

    private createPageObject(poObject: IPageObject): TypeScript.Statement {
        const className = poObject.pageobject;
        const statement = this.ts.createClassDeclaration(
            [this.ts.createDecorator(this.ts.createIdentifier("page"))],
            [this.ts.createModifier(this.ts.SyntaxKind.ExportKeyword)],
            this.ts.createIdentifier(className),
            undefined,
            undefined,
            this.createPageObjectContent(poObject.children));
        return statement;
    }

    private createPageObjectContent(poContent: any): TypeScript.ClassElement[] {
        const classContent: TypeScript.ClassElement[] = [];
        poContent.forEach((content: any) => {
            if (content.hasOwnProperty("locators")) {
                classContent.push(...this.createLocators(content.children));
            }

            if (content.hasOwnProperty("methods")) {
                classContent.push(...this.createMethods(content.children));
            }
        });

        return classContent;
    }

    private createLocators(listLocator: any): TypeScript.ClassElement[] {
        const properties: TypeScript.ClassElement[] = [];
        listLocator.forEach((locator: ILocator) => {
            const name = locator.name;
            const value = locator.value;
            const locatorDeclare = this.ts.createProperty(
                [this.ts.createDecorator(this.ts.createIdentifier("locator"))],
                [this.ts.createModifier(this.ts.SyntaxKind.PublicKeyword)],
                this.ts.createIdentifier(name),
                undefined,
                undefined,
                this.createLocatorValue(value),
            );
            properties.push(locatorDeclare);
        });
        return properties;
    }

    private createLocatorValue(value: any) {
        let locatorValue: TypeScript.Expression;
        const type = typeof value;
        if (type === "string") {
            if (value.startsWith("$")) {
                locatorValue = this.ts.createIdentifier(value.substr(1));
            } else {
                locatorValue = this.ts.createStringLiteral(value);
            }
        }
        // another type as object .. handle later
        return locatorValue;
    }

    private createMethods(listMethod: any): TypeScript.ClassElement[] {
        const methodsDeclare: TypeScript.ClassElement[] = [];
        listMethod.forEach((method: any) => {
            if (method.hasOwnProperty("method")) {
                const methodObj = method as IMethod;
                methodsDeclare.push(this.createOneMethod(methodObj));
            }
        });
        return methodsDeclare;
    }

    private createOneMethod(methodObj: IMethod): TypeScript.ClassElement {
        const methodName = methodObj.method;
        const params = methodObj.params;
        const des = methodObj.des;
        let deco: TypeScript.Decorator[];
        if (des) {
            deco = [this.createDecorator("action", des)];
        }
        return this.ts.createMethod(
            deco,
            [
                this.ts.createModifier(this.ts.SyntaxKind.PublicKeyword),
                this.ts.createModifier(this.ts.SyntaxKind.AsyncKeyword),
            ],
            undefined,
            this.ts.createIdentifier(methodName),
            undefined,
            undefined,
            this.createMethodParameters(params),
            undefined,
            this.createMethodBody(methodObj),
        );
    }

    private createDecorator(name: string, des: string[]): TypeScript.Decorator {
        const decoArg: TypeScript.Expression[] = [];
        des.forEach((description: string) => {
            decoArg.push(this.ts.createStringLiteral(description));
        });
        return this.ts.createDecorator(
            this.ts.createCall(this.ts.createIdentifier(name), undefined, decoArg)
        );
    }

    private createMethodBody(methodObj: IMethod): TypeScript.Block {
        const listStatement = this.actParser.createListStatement(methodObj.children);
        const methodReturn = methodObj.return;
        if (methodReturn) {
            const returnStatement = this.ts.createReturn(this.createExpressionValue(methodReturn));
            listStatement.push(returnStatement);
        }
        return this.ts.createBlock(listStatement, true);
    }

    private createMethodParameters(listParams: IParameter[]): TypeScript.ParameterDeclaration[] {
        const paramsDeclare: TypeScript.ParameterDeclaration[] = [];
        listParams.forEach((param: IParameter) => {
            const name = param.name;
            const type = param.type;
            const defaultParam = param.default;
            const paraNode = this.ts.createParameter(
                undefined,
                undefined,
                undefined,
                this.ts.createIdentifier(name),
                undefined,
                this.createParameterType(type),
                this.createParmeterDefaultValue(defaultParam),
            );
            paramsDeclare.push(paraNode);
        });
        return paramsDeclare;
    }

    private createParameterType(type: string): TypeScript.TypeNode {
        let typeNode: TypeScript.TypeNode;
        switch (type) {
            case "string":
                typeNode = this.ts.createKeywordTypeNode(this.ts.SyntaxKind.StringKeyword);
                break;
            case "number":
                typeNode = this.ts.createKeywordTypeNode(this.ts.SyntaxKind.NumberKeyword);
                break;
            case "boolean":
                typeNode = this.ts.createKeywordTypeNode(this.ts.SyntaxKind.BooleanKeyword);
                break;
            case "any":
                typeNode = this.ts.createKeywordTypeNode(this.ts.SyntaxKind.AnyKeyword);
                break;
            // another type ... handle later
            default:
                break;
        }
        return typeNode;
    }

    private createParmeterDefaultValue(value: any): TypeScript.Expression {
        const defaultValue = this.createExpressionValue(value);
        return defaultValue;
    }

    private createExpressionValue(value: any): TypeScript.Expression {
        let nodeValue: TypeScript.Expression;
        const type = typeof value;
        switch (type) {
            case "string":
                if (value.startsWith("$")) {
                    nodeValue = this.ts.createIdentifier(value.substr(1));
                } else {
                    nodeValue = this.ts.createStringLiteral(value);
                }
                break;
            case "number":
                nodeValue = this.ts.createNumericLiteral(String(value));
                break;
            case "boolean":
                nodeValue = (value === true) ? this.ts.createTrue() : this.ts.createFalse();
                break;
            default:
                break;
        }
        return nodeValue;

    }
}
