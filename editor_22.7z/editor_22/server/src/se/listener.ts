import DictionaryGenerator from "./common/dictionary";
import Generator from "./generator";

const LoadTypeScript = "load_ts_to_se";
const SaveAsTypeScript = "save_se_as_ts";
const GetDict = "se_get_dict";

export class IpcListener {

    public onMessage(method: string, payload: any) {
        if (method === LoadTypeScript) {
            const { workingDir, filePath, fileType } = payload;
            return Generator.generateSE(workingDir, filePath, fileType);
        } else if (method === SaveAsTypeScript) {
            const { workingDir, filePath, data } = payload;
            Generator.generateTS(data, workingDir, filePath);
        } else if (method === GetDict) {
            const projectPath: string = payload;
            return DictionaryGenerator.generateDictionary(projectPath);
        }
    }
}
