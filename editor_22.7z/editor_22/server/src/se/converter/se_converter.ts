import DictionaryGenerator, { IActionDef } from "../common/dictionary";
import {
    HookMap, IAction,
    ILocator, IMethod,
    IParameter, ItemType,
    ITestCase, ITestHook,
    ITestModule,
} from "../common/types";

export default class SEConverter {

    public static convertFromDOM(workspaceDir: string, testmodule: ITestModule)
        : { tmDescription: string, testConfigRowData: any[], testCaseRowData: any[] } {

        const tmDescription: string = testmodule.testmodule;
        const testConfigRowData: any = [];
        const testCaseRowData: any = [];
        for (const tmItem of testmodule.children) {
            if (tmItem.type === ItemType.TestCase) {
                const tc = tmItem as ITestCase;
                testCaseRowData.push(...this._convertTestCase(workspaceDir, tc));
            } else if (tmItem.type === ItemType.TestHook) {
                const th = tmItem as ITestHook;
                testConfigRowData.push(...this._convertTestHook(workspaceDir, th));
            }
        }

        if (testmodule.usingPOs) {
            for (const po of testmodule.usingPOs) {
                testConfigRowData.push({ col1: "use page", col2: po.name, col3: po.location });
            }
        }

        return {
            tmDescription,
            testConfigRowData,
            testCaseRowData,
        };
    }

    public static convertFromPageObjectDOM(workspaceDir: string, data)
        : { locators: any[], methods: any[] } {
        const locators: any = [];
        const methods: any = [];

        for (const poItem of data.children) {
            if (poItem.locators !== undefined) {
                for (const locator of poItem.children) {
                    const locatorRow = this._convertLocator(locator as ILocator);
                    locators.push(locatorRow);
                }
            } else if (poItem.methods !== undefined) {
                for (const method of poItem.children) {
                    const methodRow = this._convertMethod(workspaceDir, method as IMethod);
                    methods.push(...methodRow);
                }
            }
        }

        return {
            locators,
            methods,
        };
    }

    private static _convertTestCase(workspaceDir: string, data: ITestCase) {
        const tcObject: any = {};
        tcObject["col1"] = "Test Case";
        tcObject["col2"] = data.testcase;
        return [tcObject, ...this._convertActions(workspaceDir, data.children as IAction[])];
    }

    private static _convertTestHook(workspaceDir: string, data: ITestHook) {
        const tcObject: any = {};
        tcObject["col1"] = HookMap[data.hook];
        return [tcObject, ...this._convertActions(workspaceDir, data.children as IAction[])];
    }

    private static _convertActions(workspaceDir: string, data: IAction[]) {
        const ret = data.map((act) => this._convertAction(workspaceDir, act));
        return ret;
    }

    private static _convertAction(workspaceDir: string, act: IAction) {
        const returnVal: any = {};
        const header = "col";
        let index = 1;

        const actName = act.action;
        returnVal[`${header}${index}`] = actName;

        const actionDict = DictionaryGenerator.getDictionary(workspaceDir);

        let objActProp: IActionDef = actionDict.find((action: IActionDef) => action.method === actName);
        if (objActProp === undefined) {
            objActProp = actionDict.find((action: IActionDef) => action.keyword === "unknown");
        } else {
            returnVal[`${header}${index}`] = objActProp.keyword;
        }

        const actionArgList = objActProp.args;

        for (const arg of act.args) {
            const argInfo = actionArgList[index - 1];
            const argObj = {
                caption: Object.keys(argInfo)[0],
                value: arg,
            };
            returnVal[`${header}${++index}`] = argObj;
        }
        return returnVal;
    }

    private static _convertLocator(data: ILocator) {
        const rowLocator: any = {};

        rowLocator.col1 = "element locator";
        rowLocator.col2 = data.name;
        rowLocator.col3 = data.value;

        return rowLocator;
    }

    private static _convertParam(data: IParameter) {
        const rowParam: any = {};

        rowParam.col1 = "argument";
        rowParam.col2 = data.name;
        rowParam.col3 = data.type;
        if (data.default) {
            rowParam.col4 = data.default;
        }
        return rowParam;
    }

    private static _convertMethod(workspaceDir: string, data: IMethod) {

        // build row for method name (Ex: method - login)
        const rowMethod: any = {};
        rowMethod.col1 = "method";
        rowMethod.col2 = data.method;
        let index = 2;
        data.des.forEach((item) => {
            rowMethod[`col${++index}`] = item;
        });
        // build rows for method params
        const rowParams = [];
        for (const param of data.params) {
            const rowParam = this._convertParam(param);
            rowParams.push(rowParam);
        }

        // build rows for method actions
        const rowActions = [];
        for (const action of data.children) {
            const rowAction = this._convertAction(workspaceDir, action as IAction);
            rowActions.push(rowAction);
        }

        return [rowMethod, ...rowParams, ...rowActions];
    }
}
