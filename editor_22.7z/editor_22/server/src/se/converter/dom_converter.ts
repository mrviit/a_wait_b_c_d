import * as TypeScript from "typescript";
import { getTypescript } from "../../libloader";
import DictionaryGenerator, { IActionDef } from "../common/dictionary";
import {
    HookMap, IAction, ILocator, IMethod, IPageObject,
    IPageObjectInfo, IParameter, ItemType, ITestCase, ITestHook, ITestItem, ITestModule,
} from "../common/types";
import { POGenerator } from "../utils/parser_ts_2_dom/pageobjectGen";
import { TestModuleGenerator } from "../utils/parser_ts_2_dom/testmoduleGen";
export default class DOMConverter {

    public static convertFromSE(
        workspaceDir: string,
        data: {
            tmDescription: string,
            testConfigRowData: any[],
            testCaseRowData: any[],
        }): ITestModule {

        const testModule: ITestModule = {
            testmodule: "",
            children: [],
            type: ItemType.TestModule,
        };

        testModule.testmodule = data.tmDescription;
        const testConfigRowData: any[] = data.testConfigRowData;
        const testCaseRowData: any[] = data.testCaseRowData;

        const [testConfigs, usingPOs] = this._convertTestConfigs(workspaceDir, testConfigRowData);
        const testCases = this._convertTestCases(workspaceDir, testCaseRowData);

        testModule.children.push(...testConfigs, ...testCases);
        testModule.usingPOs = usingPOs;

        return testModule;
    }

    public static convertFromPageObject(
        workspaceDir: string,
        data: {
            locators: any[],
            methods: any[],
        }): IPageObject {
        const pageObject: IPageObject = {
            pageobject: "",
            children: [],
        };

        const locators = this._convertLocators(data.locators);
        const methods = this._convertMethods(workspaceDir, data.methods);

        pageObject.children.push(locators);
        pageObject.children.push(methods);

        return pageObject;
    }

    public static async convertPageObjectFromTS(tsFilePath: string): Promise<IPageObject> {
        const ts = await this.loadTypeScript();
        const poGenerator = new POGenerator(ts);
        const pageObject = poGenerator.generatePOModel(tsFilePath);
        return pageObject;
    }

    public static async convertTestModuleFromTS(tsFilePath: string): Promise<ITestModule> {
        const ts = await this.loadTypeScript();
        const tmGenerator = new TestModuleGenerator(ts);
        const testModule = tmGenerator.generateTMModel(tsFilePath);
        return testModule;
    }

    private static ts: typeof TypeScript;

    private static async loadTypeScript() {
        if (!this.ts) {
            this.ts = await getTypescript();
        }
        return this.ts;
    }

    private static _convertTestConfigs(workspaceDir: string, data: any[]): [ITestItem[], IPageObjectInfo[]] {
        const resItem: ITestItem[] = [];
        const usingPOs: IPageObjectInfo[] = [];
        const dataBlocks = this._detectBlock(data, Object.values(HookMap));

        for (const block of dataBlocks.blocks) {
            const tcData = block[0];
            const arrActions = block.slice(1, block.length);

            const tc = this._createTestHook(workspaceDir, tcData, arrActions);
            resItem.push(tc);
        }

        for (const line of dataBlocks.unknownBlocks) {
            if (line["col1"] === "use page") {
                usingPOs.push({ name: line["col2"], location: line["col3"] });
            }
        }

        return [resItem, usingPOs];
    }

    private static _convertTestCases(workspaceDir, data: any[]): ITestItem[] {
        const resItem: ITestItem[] = [];

        const dataBlocks = this._detectBlock(data, ["Test Case"]);

        if (dataBlocks.unknownBlocks.length > 0) {
            const tc = this._createTestCase(workspaceDir, undefined, dataBlocks.unknownBlock);
            resItem.push(tc);
        }

        if (dataBlocks.blocks.length > 0) {
            for (const block of dataBlocks.blocks) {
                const tcData = block[0];
                const arrActions = block.slice(1, block.length);

                const tc = this._createTestCase(workspaceDir, tcData, arrActions);
                resItem.push(tc);
            }
        }

        return resItem;
    }

    private static _convertLocators(data: any[]) {
        const objLocators = {
            locators: "",
            children: [],
        };
        for (const item of data) {
            const locator = this._createLocator(item);
            objLocators.children.push(locator);
        }
        return objLocators;
    }

    private static _convertMethods(workspaceDir: string, data: any[]) {
        const objMethods = {
            methods: "",
            children: [],
        };
        const dataBlocks = this._detectBlock(data, ["method"]);
        for (const block of dataBlocks.blocks) {
            const methodRow = block[0];
            const paramRows = [];
            let actionRows = [];
            for (let index = 1; index < block.length; index++) {
                const row = block[index];
                if (row.col1 === "argument") {
                    paramRows.push(row);
                } else {
                    actionRows = block.slice(index, block.length);
                    break;
                }
            }
            const method = this._createMethod(workspaceDir, methodRow, paramRows, actionRows);
            objMethods.children.push(method);
        }
        return objMethods;
    }

    private static _detectBlock(data: any[], blockIdentifier: string[]) {
        const dataBlocks: any = {
            blocks: [],
            unknownBlocks: [],
        };

        const indexes = data.reduce((acc, curLine, index) => {

            const objLineText = Object.values(curLine)[0];
            if (objLineText === undefined) {
                return acc;
            }
            const lineText = objLineText.toString().toLowerCase();

            // lower case indetifier strings
            const lowerIdentifier = blockIdentifier.map((identifier) => {
                return identifier.toLowerCase();
            });

            if (lowerIdentifier.includes(lineText)) {
                acc.push(index);
            }

            return acc;
        }, []);

        if (indexes.length === 0) {
            dataBlocks.unknownBlocks = data;
            return dataBlocks;
        }

        let prevIndex = -1;
        for (const index of indexes) {
            if (index === 0) {

                /* do nothing */

            } else if (prevIndex === -1) {
                dataBlocks.unknownBlocks = data.slice(0, index);
            } else {
                let blockTC = [];
                blockTC = data.slice(prevIndex, index);
                dataBlocks.blocks.push(blockTC);
            }

            // update prevIndex
            prevIndex = index;
        }

        // handle last TC
        if (prevIndex < data.length) {
            const blockTC = data.slice(prevIndex, data.length);
            dataBlocks.blocks.push(blockTC);
        }

        return dataBlocks;
    }

    private static _createTestCase(workspaceDir: string, tcData: any, arrChildrens: any[]): ITestCase {

        const testcase: ITestCase = {
            testcase: "",
            children: [],
            type: ItemType.TestCase,
        };

        if (tcData === undefined) {
            testcase.testcase = "";
        } else {
            const tcName = Object.values(tcData)[1];
            testcase.testcase = tcName === undefined ? "" : tcName.toString();
        }

        for (const line of arrChildrens) {
            const action = this._convertActionLine(workspaceDir, line);
            testcase.children.push(action);
        }

        return testcase;
    }

    private static _createTestHook(workspaceDir: string, thData: any, arrChildrens: any[]): ITestHook {

        const testhook: ITestHook = {
            hook: "",
            children: [],
            type: ItemType.TestHook,
        };

        const hookType = Object.values(thData)[0];
        const hookText = hookType === undefined ? "" : hookType.toString();
        testhook.hook = Object.keys(HookMap).find((key) => HookMap[key] === hookText);

        for (const line of arrChildrens) {
            const action = this._convertActionLine(workspaceDir, line);
            testhook.children.push(action);
        }

        return testhook;
    }

    private static _createMethod(workspaceDir: string, methodRow: any, paramRows: any[], actionRows: any[]) {

        const method: IMethod = {
            method: "",
            params: [],
            des: [],
            children: [],
        };

        if (methodRow !== undefined) {
            const methodName = methodRow.col2;
            method.method = (methodName === undefined) ? "" : methodName.toString();
            const size = Object.keys(methodRow).length;
            for (let idx = 0; idx < size; idx++) {
                const key = Object.keys(methodRow)[idx];
                if (key !== "col1" && key !== "col2") {
                    const value = Object.values(methodRow)[idx].toString();
                    if (value) {
                        method.des.push(value);
                    }
                }
            }
        }

        for (const paramRow of paramRows) {
            const param = this._convertParamLine(paramRow);
            method.params.push(param);
        }

        for (const actionRow of actionRows) {
            const action = this._convertActionLine(workspaceDir, actionRow);
            method.children.push(action);
        }

        return method;
    }

    private static _createLocator(locatorData: any): ILocator {
        const locator: ILocator = {
            name: "",
            value: "",
        };

        const locatorName = Object.values(locatorData)[1];
        if (locatorName) {
            locator.name = locatorName.toString();
        }
        const locatorValue = Object.values(locatorData)[2];
        if (locatorValue) {
            locator.value = locatorValue.toString();
        }

        return locator;
    }

    private static _convertParamLine(data: any) {
        const param: IParameter = {
            name: "",
            type: "any",
        };

        if (data.col2 !== undefined) {
            param.name = data.col2;
        }
        if (data.col3 !== undefined && data.col3 !== "") {
            param.type = data.col3;
        }
        if (data.col4 !== undefined) {
            param.default = this._convertType(data.col4, param.type);
        }

        return param;
    }

    private static _convertActionLine(workspaceDir: string, data: any) {
        const action: IAction = {
            action: "",
            args: [],
            type: ItemType.Action,
        };

        const arrKey = Object.keys(data);
        // get action name
        const actName = data[arrKey[0]];
        action.action = actName;

        const actionDict = DictionaryGenerator.getDictionary(workspaceDir);

        // get action's properties
        let objActProp = actionDict.find((act: IActionDef) => act.keyword === actName);
        if (objActProp === undefined) {
            objActProp = actionDict.find((act: IActionDef) => act.keyword === "unknown");
        } else {
            action.action = objActProp.method;
        }

        const actionArgList = objActProp.args;

        for (let index = 0; index < actionArgList.length; index++) {
            const argInfo = actionArgList[index];
            const objArg = data[arrKey[index + 1]];
            const strValue = (objArg instanceof Object) ? objArg.value : objArg;
            // get Type of argument
            const type = Object.values(argInfo)[0] as string;
            // convert string to correct type
            const value = this._convertType(strValue, type);
            action.args.push(value);
        }

        return action;
    }

    private static _convertType(data: any, type: string) {
        let res: any;
        if (type === "number") {
            res = parseInt(data, 10);
        } else if (type === "boolean") {
            if (data === "true") {
                res = true;
            } else if (data === "false") {
                res = false;
            } else {
                res = NaN;
            }
        } else {
            res = data;
        }

        if (isNaN(res)) {
            res = data;
        }

        return res;
    }
}
