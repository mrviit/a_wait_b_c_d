// NOTICE THAT: this is a dev dependency only. do not use directly
import * as TypeScript from "typescript";
import { getTypescript } from "../../libloader";
import { IPageObject, ITestModule } from "../common/types";
import { PageObjectParser } from "../utils/parser_dom_2_ts/pageobjectParser";
import { TestModuleParser } from "../utils/parser_dom_2_ts/testmoduleParser";
import { printNode } from "../utils/printNode";

export default class TSConverter {

    public static async convertTestModuleFromDOM(data: ITestModule): Promise<string> {

        const ts = await getTypescript();
        const tmParser: TestModuleParser = new TestModuleParser(ts);
        const statements: TypeScript.Statement[] = tmParser.parseTestModule(data);

        let tsOutput: string = "";
        statements.forEach((state) => {
            tsOutput += printNode(ts, state) + "\n";
        });

        return tsOutput;
    }

    public static async convertPageObjectFromDOM(data: IPageObject): Promise<string> {

        const ts = await getTypescript();
        const poParser: PageObjectParser = new PageObjectParser(ts);
        const statement: TypeScript.Statement[] = poParser.parsePageObject(data);

        let tsOutput: string = "";
        statement.forEach((state) => {
            tsOutput += printNode(ts, state) + "\n";
        });

        return tsOutput;
    }
}
