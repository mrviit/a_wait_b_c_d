
import {
    Connection,
 } from "vscode-languageserver";

let connection: Connection;

export function initDiagnostic(conn: Connection) {
    connection = conn;
}

export function info(message: string) {
    connection!.console.info(message);
}

export function error(message: string) {
    connection!.console.error(message);
}

export function warn(message: string) {
    connection!.console.warn(message);
}

/**
 * log information. it should be remove when build release
 * @param message message for loging
 */
export function log(message: string) {
    connection!.console.info(`Time: ${(new Date()).getTime()} ${message}`);
}

function createLogger_release(tag: string) {
    return (msg: string) => { };
}

// use createLogger_debug for debugging
export const createLogger = createLogger_debug;

function createLogger_debug(tag: string) {
    let date = new Date();
// tslint:disable-next-line: variable-name
    const _tag = tag;
    function mylog(message: string) {
        const newTime = new Date();
    // tslint:disable-next-line: max-line-length
        connection!.console.info(`[${_tag} - Duration: ${newTime.getTime() - date.getTime()}]   ${message}`);
        date = newTime;
    }

    return mylog;
}
