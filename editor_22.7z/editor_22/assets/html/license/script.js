const vscode = acquireVsCodeApi();

const ip = document.getElementById('ip');
const port = document.getElementById('port');
const okButton = document.getElementById('ok_button');
const errorMessage = document.getElementById('error_message');
const editonValue = document.getElementById('editon_value');
const expireValue = document.getElementById('expire_value');
const instanceValue = document.getElementById('instance_value');

okButton.addEventListener("click", checkLicense);
function checkLicense() {
    vscode.postMessage({
        command: 'checkLicense',
        payload:{
            host: ip.value,
            port: port.value
        }
    });
}

ip.addEventListener("input", enableOkButton);
port.addEventListener("input", enableOkButton);
function enableOkButton() {
    okButton.disabled = false;
}

window.addEventListener('message', event => {
    
    console.log(JSON.stringify(event.data));
    
    const payload = event.data.payload;
    const command = event.data.command;
    switch (command) {
        case 'enableBtnOK':
            okButton.disabled = false;
            ip.disabled = false;
            port.disabled = false;
            break;
        case 'disableBtnOK':
            okButton.disabled = true;
            ip.disabled = true;
            port.disabled = true;
            break;
        case 'licenseInfo':
            
            if (payload.licenseState == 0) {
                okButton.disabled = true;
            }
            editonValue.innerHTML = payload.licenseEdition;
            expireValue.innerHTML = payload.expiredDate;
            instanceValue.innerHTML = payload.instanceID;
            break;
        case 'licenseServer':
            
            // errorMessage.innerHTML = JSON.stringify(message.licenseServer);
            if (payload.licenseInfo.licenseState == 0) {
                okButton.disabled = true;
            }
            ip.value = payload.host;
            port.value =payload.port;
            editonValue.innerHTML = payload.licenseInfo.licenseEdition;
            expireValue.innerHTML = payload.licenseInfo.expiredDate;
            instanceValue.innerHTML = payload.licenseInfo.instanceID;
            break;
    }
});