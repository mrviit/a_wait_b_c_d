
var handlers = {};
handlers["injectData"] = handleInjectData;
handlers["exportData"] = exportData;
handlers["injectDict"] = handleInjectDict;

const Grid = {
    LOCATORS: "#locators_grid",
    METHODS: "#methods_grid",
}

function handleInjectData(payload) {
    let locators = null;
    let methods = null;
    
    if (payload) {
        locators = payload.locators;
        methods = payload.methods;
    }

    injectGridData(gridMap.get(Grid.LOCATORS), locators, [{[`${COL_1}`]: "element locator"}]);
    injectGridData(gridMap.get(Grid.METHODS), methods, [{[`${COL_1}`]: "method"}]);
}

/*
 * handle event on "export data" button
 */
function exportData() {
    const result = {
        locators: [],
        methods: [],
    };

    result.locators = getGridData(gridMap.get(Grid.LOCATORS).gridOptions);
    result.methods = getGridData(gridMap.get(Grid.METHODS).gridOptions);

    console.log("exportData", JSON.stringify(result));
    vscode.postMessage({
        command: 'exportData',
        payload: result
    })
}

function handleInjectDict(payload) {
    console.log(payload);
    actionDictionary = payload;
}

// listener message from extension
function onMessageReceived(command, payload) {
    console.log(command, payload);
    let handler = handlers[command];
    if (handler) {
        handler(payload);
    } else {
        console.log(`Handler not found: command: ${command} payload: ${payload}`);
    }
}

function initListener() {
    window.addEventListener('message', event => {
        const message = event.data;
        onMessageReceived(message.command, message.payload);
    });
}

function loadUI() {
    document.addEventListener('DOMContentLoaded', function () {
        initGrid(Grid.LOCATORS);
        initGrid(Grid.METHODS);
        initListener();

        window.onresize = function (event) {
            gridMap.forEach((gridObj) => {
                udpateColumnSize(gridObj.gridHTMLElement, gridObj.gridOptions);    
            });
        };
    });
}

loadUI();