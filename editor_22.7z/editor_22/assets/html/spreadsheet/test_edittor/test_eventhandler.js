var handlers = {};
handlers["injectData"] = handleInjectData;
handlers["exportData"] = exportData;
handlers["injectDict"] = handleInjectDict;

const Grid = {
    TEST_CONFIGURATIONS: "#th_grid",
    TEST_CASES: "#tc_grid",
}

function handleInjectData(payload) {

    let tmDescription = "";
    let testConfigRowData = null;
    let testCaseRowData = null;

    if (payload) {
        tmDescription = payload.tmDescription;
        testConfigRowData = payload.testConfigRowData;
        testCaseRowData = payload.testCaseRowData;
    }

    if (testConfigRowData && testConfigRowData.length > 0) {
        expandTestConfig();
    }

    setTMDescription(tmDescription);
    injectGridData(gridMap.get(Grid.TEST_CONFIGURATIONS), testConfigRowData, [{
        [`${COL_1}`]: ""
    }]);
    injectGridData(gridMap.get(Grid.TEST_CASES), testCaseRowData, [{
        [`${COL_1}`]: "Test Case"
    }]);
}

function expandTestConfig() {
    const btnCollapse = document.getElementById("th_btn");
    btnCollapse.classList.remove("button-expand");
    btnCollapse.classList.add("button-collapse");
    const th_grid = document.getElementById("th_grid");
    th_grid.style.display = "block";
}

function setTMDescription(description) {
    const tmDescription = document.getElementById("tm_description");

    if (tmDescription !== undefined) {
        tmDescription.value = description;
    }
}

function getTMDescription() {
    const tmDescription = document.getElementById("tm_description");
    if (tmDescription !== undefined) {
        return tmDescription.value;
    }

    return "";
}

/*
 * handle event on "export data" button
 */
function exportData() {
    const result = {
        tmDescription: "",
        testConfigRowData: [],
        testCaseRowData: [],
    };

    result.tmDescription = getTMDescription();

    result.testConfigRowData = getGridData(gridMap.get(Grid.TEST_CONFIGURATIONS).gridOptions);
    result.testCaseRowData = getGridData(gridMap.get(Grid.TEST_CASES).gridOptions);

    console.log("exportData", JSON.stringify(result));
    vscode.postMessage({
        command: 'exportData',
        payload: result
    })
}

function handleInjectDict(payload) {
    console.log(payload);
    actionDictionary = payload;
}

// listener message from extension
function onMessageReceived(command, payload) {
    console.log(command, payload);
    let handler = handlers[command];
    if (handler) {
        handler(payload);
    } else {
        console.log(`Handler not found: command: ${command} payload: ${payload}`);
    }
}

function initListener() {
    window.addEventListener('message', event => {
        const message = event.data;
        onMessageReceived(message.command, message.payload);
    });
}

function loadUI() {
    document.addEventListener('DOMContentLoaded', function () {
        initGrid(Grid.TEST_CONFIGURATIONS);
        initGrid(Grid.TEST_CASES);
        initListener();

        window.onresize = function (event) {
            gridMap.forEach((gridObj) => {
                udpateColumnSize(gridObj.gridHTMLElement, gridObj.gridOptions);
            });
        };
    });

    var input = document.getElementById("tm_description");
    input.addEventListener("keydown", function (event) {
        if (event.key === 'Enter') {
            editNextCellOnEnter();
        }
    });
}

function editNextCellOnEnter() {
    const grid = gridMap.get(Grid.TEST_CONFIGURATIONS).gridOptions ||
        gridMap.get(Grid.TEST_CASES).gridOptions;
    if (grid) {
        grid.api.setFocusedCell(0, `${COL_1}`);
        grid.api.startEditingCell({
            rowIndex: 0,
            colKey: `${COL_1}`
        });
    }
}

loadUI();