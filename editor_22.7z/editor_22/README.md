# Gondola Studio for Visual Studio Code

Gondola Studio is an extension for Visual Studio Code that helps you to create, manage, and execute automation tests using [Gondola](https://www.gondolatest.com) Framework. 

## Installation

* You must install Visual Studio Code beforehand
* After installing Visual Studio Code, install NodeJS/npm

## Features

### Input your license information

* Input your license information (machine name and port number) into Gondola Studio to start using Gondola.
* Note that the current version of Gondola only supports the on-premises license server type. Cloud support is on the horizon.
* View the in-used license information such as license type and expiration date.

### Quickly create your Gondola project

* Create a Gondola project that matches your testing purpose with predefined structure, configurations, and sample tests.

### Gondola Studio Explorer (coming soon)

* Focus your attention on important Gondola test artifacts and ignore the peripheral artifacts such as configuration files.
* Manage and execute your automation tests faster.

### Test execution 

* Execute your tests with a variety of options.

### Install Gondola Framework silently

* Silently install Gondola Framework into your working machine.
* Download all required dependencies for your test project. Note that this feature requires internet connection.

## Commands

You can use the following commands.

<!---
Please insert gondola commands here
--->

## Quick Start guide

> You must select **Mobile Sample** project type when creating a new Gondola project to have the sample tests ready

## EULA

Please read our End User License Agreement [here](https://gondolatest.com/en/eula/).

## Privacy Policy

Please read our Privacy Policy [here](https://gondolatest.com/en/privacy-policy/).

## Support

Read the docs of Gondola [here](http://docs.gondolatest.com). Should you have any problems, feel free to email us at <support@gondolatest.com>.