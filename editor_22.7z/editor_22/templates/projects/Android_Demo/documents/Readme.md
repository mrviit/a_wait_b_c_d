# Requirement:
- NodeJS LTS
- Python 2.7 (required by Appium's node_gyp)
- VSCode Cucumber (Gherkin) Support 

# Installation
```bash
npm i -g appium webdriverio appium-doctor @wdio/sync typescript allure-commandline #Global packages
```

# Create test
1. Write your test in BDD (Given, When, Then,...)
2. [IN PROGRESS] Generate the needed low level steps
```bash
gondola gherkin:snippets
```
3. Implement these low level steps

# Run
- Step 1: Start appium server and keep it running
```bash
appium
```

- Step 2: Run test (on another console)
```bash
npm test
```
Or
```bash
./node_modules/.bin/gondola run --steps --plugins allure
```

- Step 3: View the result
```bash
allure serve output
```

# Some notes
1. UIAtomatorViewer and Appium Server are conflicting to each other. Don't keep them run at the same time.
2. Mochawesome is terrible
3. As BDD is plain text, it's hard to maintain in case:
  - Change the step description, parameters,...
  - Change the control or its value
4. I cannot find the way to combine some steps to bigger one (high level step) => duplicated code happens
5. Have not tried error handling yet
