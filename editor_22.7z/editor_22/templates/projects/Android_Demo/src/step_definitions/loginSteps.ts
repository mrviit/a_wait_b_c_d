import {gondola} from "gondolajs";
import loginPage from "../pages/loginPage";
import { getPageClass } from "../common/utils";

Given("I start {string}", (pageName: string) => {
    const pageClass = getPageClass(pageName);
    if (pageClass){
        const packageId = pageClass.packageId;
        if (packageId){
            gondola.runOnAndroid(async () => {
                await gondola.checkAppIsInstalled(typeof(packageId) === "string" ? 
                    packageId : packageId.android!);
            });
        }
        //gondola.wait(5);
    } else {
        throw new Error("Invalid page was given. Page is not found or corrupted.");
    }
});

When("I login by username {string} and password {string}", async (user: string, pass: string) => {
    await loginPage.login(user, pass);
});

Then("I should see {string} of {string}", (ele: string, parent: string) => {
    let parentPage;
    if (parent){
        parentPage = getPageClass(parent);
    }

    let toCheck = ele;
    if (parentPage && parentPage.hasOwnProperty(ele)){
        toCheck = parentPage[ele];
    }
    gondola.checkControlExist(toCheck);
});
