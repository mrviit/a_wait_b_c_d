import {gondola} from "gondolajs";
import loginPage from "../pages/loginPage";
import * as users from "../../data/users.json";
import * as carReservations from "../../data/carReservations.json";
import homePage from "../pages/homePage";
import orderPage from "../pages/orderPage";

Given("I am logged in as {string}", async (userName: string) => {
    const user = users.default[userName];
    if (user) {
        await loginPage.login(userName, user.password);
    } else {
        throw new Error(`Test data doesn't contain user '${userName}'`);
    }
});

When("I rent a {string} for {int} day", async(carName: string, rentedDays: number) => {
    await homePage.openNewOrder();
    await orderPage.enterPickUpInfo(
                carReservations.default.default.location.pickup);
    await orderPage.enterReturnInfo(
                carReservations.default.default.location.return);
    await orderPage.selectCar(carName);
    await orderPage.setRentedDays(rentedDays);
    await orderPage.enterCustomerInfo(
                carReservations.default.default.customer.firstName,
                carReservations.default.default.customer.lastName,);
});

When("I select option {string}", async(option: string) => {
    await orderPage.selectOptions(option);
    await orderPage.selectPrice();
});

Then("I should see the total payment is {float}", async(price: number) => {
    await orderPage.checkTotalPrice(price.toFixed(2));
});

