import {gondola} from "gondolajs";
import orderPage, { OrderPage } from "../pages/orderPage";

export class HomePage implements IPage {
    public static pageTitle = {
        android: "//android.widget.TextView[@text=\"Welcome\" or @text=\"WELCOME\"]"
    };

    public static pageId = {
        android: ".welcome",
    };

    public static newOrder = {
        android: "~Button New Order"
    };

    public async openNewOrder(): Promise<OrderPage> {
        await gondola.waitForElement(HomePage.newOrder,5);
        await gondola.tap(HomePage.newOrder);
        return orderPage;
    }
}

export default new HomePage();