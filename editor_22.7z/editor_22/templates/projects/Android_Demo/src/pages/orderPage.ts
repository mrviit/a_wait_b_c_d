import {gondola} from "gondolajs";

export class OrderPage implements IPage {
    public static pickDate = {
        android: "~Text View Current Date"
    };

    public static pickState = {
        android: "#com.logigear:id/spinStates"
    };

    public static pickCity = {
        android: "~Pickup City"
    };

    public static nextButton = {
        android: "~Button Next"
    };

    public static nextButtonId = {
        android: "#com.logigear:id/btnNext"
    };

    public async enterPickUpInfo(pickUpInfo: any): Promise<OrderPage> {
        //Pickup info page

        await gondola.runOnAndroid(async () => {
            await gondola.enter(OrderPage.pickDate, new Date().toDateString());
        });
        await gondola.tap({
            android: pickUpInfo.country
        });
        await gondola.runOnAndroid(async () => {
            await gondola.tap(OrderPage.pickState);
            await gondola.tap({
                android: pickUpInfo.state
            });
        });
        
        await gondola.enter(OrderPage.pickCity, pickUpInfo.city);
        await gondola.runOnAndroid(async()=> {
            await gondola.tap(OrderPage.nextButton);
        });
        return this;
    }

    public async enterReturnInfo(returnInfo: any): Promise<OrderPage> {
        //Return info page
        await gondola.waitForElement(OrderPage.nextButtonId,5);
        await gondola.tap(OrderPage.nextButtonId);
        return this;
    }

    public async selectCar(carName: string): Promise<OrderPage> {
        //Car selection page
        await gondola.tap({
            android: carName
        });
        return this;
    }

    public async setRentedDays(rentDays: number): Promise<OrderPage> {
        //Car detail page
        await gondola.runOnAndroid(async()=>{
            await gondola.enter("~Rental Duration", `${rentDays}`);
        });
        await gondola.tap(OrderPage.nextButton);
        return this;
    }

    public async enterCustomerInfo(firstName: string,lastName:string): Promise<OrderPage> {
        //Customer info page
        await gondola.enter(
            {
                android: "~First Name"
             }, firstName);
        await gondola.enter(
            {
                android: "~Last Name"
            }, lastName);
        await gondola.enter(
            {
                android: "~Driver License"
            }, "123");
        await gondola.tap(OrderPage.nextButtonId);
        return this;
    }

    public async selectOptions(options: string | string[]): Promise<OrderPage> {
		await gondola.wait(1);
        if (options && options !== "N/A") {
            if (typeof(options) === "string"){
                await this.selectOption(options);
            } else {
                await Promise.all(options.map(async(option) => {
                    await this.selectOption(option);
                }));
            }
        }
        await gondola.tap(OrderPage.nextButton);
        return this;
    }

    private async selectOption(option: string){
        const ele = {
            android: `//android.widget.TextView[@text="${option}"]/following-sibling::android.widget.CheckBox`
        };

        await gondola.tap(ele);
    }

    public async selectPrice(): Promise<OrderPage> {
        await gondola.waitForElement(OrderPage.nextButtonId,5);
        await gondola.tap(OrderPage.nextButtonId);
        return this;
    }

    public async checkTotalPrice(price: string): Promise<OrderPage> {
        await gondola.waitForElement({
            android: "PAYMENT INFORMATION"
        },5);
        await gondola.tap({
            android: "PAYMENT INFORMATION"
        });
        await gondola.checkControlProperty({
            android: "~Total Payment"
         }, "text", price);

        return this;
    }
}

export default new OrderPage();