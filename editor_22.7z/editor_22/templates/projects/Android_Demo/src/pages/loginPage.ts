import {gondola} from "gondolajs";
import homePage, { HomePage } from "../pages/homePage";

export class LoginPage implements IPage {
    public static packageId = "com.logigear";
    public static pageId = "com.logigear.SplashActivity";

    public static usrTextbox = { 
        android: "~User Name"
    };
    public static pwdTextbox = {
        android: "#com.logigear:id/txtPassword"
    };
    public static loginBtn = {
        android: "//android.widget.Button[@content-desc=\"Button Login\"]"
    };
    public static InvalidMsg = {
        android: "//android.widget.TextView[@text=\"Invalid UserName or Password.\"]", //text
    }

    public async login(user:string, pass: string): Promise<HomePage> {
        await gondola.waitForElement(LoginPage.usrTextbox, 5);
        await gondola.enter(LoginPage.usrTextbox, user);
        await gondola.enter(LoginPage.pwdTextbox, pass);
        await gondola.tap(LoginPage.loginBtn);
        return homePage;
    }
}
export default new LoginPage();