

interface IPage {
    packageId?: ILocator | string,
    pageId?: ILocator | string,
    pageTitle?: ILocator | string,

    [key:string]: any;
}