export function getPageObject(pageName: string): IPage | null {
    if (pageName){
        const pageObject = require(`../pages/${pageName}`);
        return pageObject.default as IPage;
    } else {
        return null;
    }
}

export function getPageClass(pageName: string): IPage | null {
    const pageObject = getPageObject(pageName);
    return pageObject ? pageObject.constructor as IPage : null;
}