import { action, gondola, locator, page } from "gondolajs";
@page
export class loginPage {
    @locator
    public userNameTxtbox = "~User Name";
    @locator
    public passwordTxtbox = "~Password";
    @locator
    public loginBtn = "~Button Login";
    @action("login", "Login Car Rental app")
    public async login(userName: string, password: string) {
        await gondola.waitForElement(this.userNameTxtbox, 20);
        await gondola.enter(this.userNameTxtbox, userName);
        await gondola.enter(this.passwordTxtbox, password);
        await gondola.tap(this.loginBtn);
    }
}
export default new loginPage();
