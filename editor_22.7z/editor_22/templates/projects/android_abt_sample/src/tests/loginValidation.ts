import { gondola, TestCase, TestModule } from "gondolajs";
import loginPage from "../pages/loginPage";

TestModule("Login Validation");

TestCase("Valid login (Access granted)", async () => {
  await loginPage.login("john", "");
  await gondola.checkControlExist("Welcome");
});
