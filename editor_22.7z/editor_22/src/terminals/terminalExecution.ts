
import * as vscode from "vscode";
import { sleep } from "../utils";
import { buildCommandline, getTerminalShellPath, isCMDShell } from "./helper";

const TERMINAL_NAME = "Gondola";

enum TerminalType {
    Unknown,
    CommandPrompt,
    Powsershell,
}

class TerminalService {

    public terminal!: vscode.Terminal | undefined;

    public terminalType = TerminalType.Unknown;

    public TerminalService() {
        /* ; */
    }

    public async execute(cmd: string, args: string[], path: string) {
        await this.ensureTerminal();
        await this.setCwd(path);
        await this.sendCommand(cmd, args);
    }

    /**
     * execute cd commandline
     * @param path path of folder
     */
    private async setCwd(path: string) {
        const cmd = "cd ";
        const args: string[] = [];
        // append /d argument for commandline in case cmd mode. fix bug vscode on win7
        if (this.terminalType === TerminalType.CommandPrompt) {
            args.push("/d");
        }
        args.push(path);

        await this.sendCommand(cmd, args);
    }
    private async sendCommand(cmd: string, args: string[] = []) {
        this.terminal!.show(true);
        const commandline = buildCommandline(cmd, args);
        this.terminal!.sendText(commandline, true);
    }

    /**
     * handle event when user close terminal
     */
    private registerClose() {
        vscode.window.onDidCloseTerminal((terminal) => {
            if (terminal === this.terminal
                || terminal.name === TERMINAL_NAME) {
                this.terminal = undefined;
            }
        });
    }

    /*
    * find the gondola terminal in case it was created previously
    */
    private findTerminal() {
        if ((vscode.window).terminals.length === 0) {
            return null;
        }

        const terminals = ((vscode.window as any).terminals) as vscode.Terminal[];
        return terminals.find((t) => t.name === TERMINAL_NAME);

    }

    private createTerminal() {
        const shellString = getTerminalShellPath();
        this.terminalType = isCMDShell(shellString) ? TerminalType.CommandPrompt : TerminalType.Unknown;
        this.terminal = vscode.window.createTerminal(TERMINAL_NAME, shellString);
    }

    /*
    * create a terminal
    */
    private async ensureTerminal(preserveFocus: boolean = true) {

        if (!this.terminal) {
            const t = this.findTerminal();
            if (t) {
                this.terminal = t;
            }
        }

        if (!this.terminal) {
            this.createTerminal();
            // sleep a litle to wait for UI respone
            await sleep(100);
            this.registerClose();
        }
        if (this.terminal) {
            this.terminal.show(preserveFocus);
            // sleep a litle to wait for UI respone
            await sleep(100);
        }

    }

}
export const terminalService = new TerminalService();
