import {workspace} from "vscode";
import {OSType, Platform} from "./../utils";

/**
 * build to text of commandline which is used for terminal
 * @param cmd
 * @param args
 */
export function buildCommandline( cmd: string, args: string[] = []): string {

    let commandline = cmd;

    for ( const arg of args) {
        if ( arg.indexOf(" ") > 0 ) {
            commandline += ` "${arg}"`;
        } else {
            commandline += ` ${arg}`;
        }
    }

    return commandline;

}

const IS_COMMAND = /cmd.exe$/i;

export function isCMDShell(shellPath: string) {
    // let path = getTerminalShellPath();
    return IS_COMMAND.test(shellPath);
}

export function getTerminalShellPath(): string {
    const shellConfig = workspace.getConfiguration("terminal.integrated.shell");
    let osSection = "";
    switch (Platform.osType) {
        case OSType.Windows: {
            osSection = "windows";
            break;
        }
        case OSType.OSX: {
            osSection = "osx";
            break;
        }
        case OSType.Linux: {
            osSection = "linux";
            break;
        }
        default: {
            return "";
        }
    }
    return shellConfig.get<string>(osSection)!;
}
