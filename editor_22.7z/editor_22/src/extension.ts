
import * as license from "gondola-license";
import * as vscode from "vscode";

import { createProject } from "./commands/createProject";
import { newPage } from "./commands/newPage";
import { newTest } from "./commands/newTest";
import { exportData, openWithABTEditor } from "./commands/openWithABTEditor";
import { showLicenseForm } from "./commands/showLicenseForm";
import { watchSrc } from "./commands/watchSrc";
import { extensionCmds, sideBar } from "./constantTexts";
import { ext } from "./extensionVariables";
import { registerCommand, registerOutputChanel } from "./utils";

import { registerAndWaitClientReady, unregisterClient } from "./clientipc/client";
import { checkLicenseWhenActive } from "./commands/checkLicense";
import { info } from "./output";
import { GondolaSideBarDataProvider } from "./sidebar/GondolaSideBarDataProvider";

// this method is called when your extension is activated
// your extension is activated the very first time the command is executed
export async function activate() {

    registerCommand(extensionCmds.showLicenseForm, showLicenseForm);
    registerCommand(extensionCmds.createProject, createProject);
    registerCommand(extensionCmds.openWithABTEditor, openWithABTEditor);
    registerCommand(extensionCmds.exportData, exportData);
    registerCommand(extensionCmds.newPage, newPage);
    registerCommand(extensionCmds.newTest, newTest);
    registerCommand(extensionCmds.watchSrc, watchSrc);

    registerOutputChanel();

    // const previewAndCloseSrcDoc = async (document: vscode.TextDocument): Promise<void> => {
    //     const path = await import("path");
    //     if (document.languageId === "typescript"
    //         && path.basename(document.uri.fsPath).includes("gse")
    //     ) {
    //         await vscode.commands.executeCommand("workbench.action.closeActiveEditor");
    //         await vscode.commands.executeCommand(extensionCmds.openWithABTEditor, document.uri);
    //     }
    // };

    // vscode.workspace.onDidOpenTextDocument(async (document: vscode.TextDocument) => {
    //     previewAndCloseSrcDoc(document);
    // });

    // if (vscode.window.activeTextEditor) {
    //     previewAndCloseSrcDoc(vscode.window.activeTextEditor.document);
    // }

    ext.statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 1);
    ext.defaultItemColor = ext.statusBarItem.color;

    await checkLicenseWhenActive();

    ext.sidebarDataProvider = new GondolaSideBarDataProvider();
    ext.sidebar = vscode.window.createTreeView(
        sideBar.id,
        { treeDataProvider: ext.sidebarDataProvider });

    registerAndWaitClientReady();
    info("Gondola is actived");
}

// this method is called when your extension is deactivated
export async function deactivate() {
    unregisterClient();
    info("Gondola is deactived");
    await license.stop();
}
