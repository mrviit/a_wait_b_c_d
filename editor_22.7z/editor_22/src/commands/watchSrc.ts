import fs from "fs";
import path from "path";
import ts from "typescript";
import vscode from "vscode";
import * as texts from "../constantTexts";

let watcher: vscode.FileSystemWatcher;

export async function watchSrc() {
    if (!watcher) {
        const wsp = vscode.workspace.workspaceFolders![0];
        if (!wsp) {
            vscode.window.showInformationMessage("There are no workspace");
            return;
        }
        const tsconfig = path.join(wsp.uri.fsPath, "tsconfig.json");
        if (!fs.existsSync(tsconfig)) {
            vscode.window.showInformationMessage("There are no tsconfig.json");
            return;
        }

        const tsconfigTxt = fs.readFileSync(tsconfig, "utf-8");
        const tsconfigJson = ts.parseConfigFileTextToJson(tsconfig, tsconfigTxt);
        if (tsconfigJson.error) {
            vscode.window.showInformationMessage("Error on parsing tsconfig.json");
            return;
        }

        watcher = vscode.workspace.createFileSystemWatcher(
            path.join(wsp.uri.fsPath, tsconfigJson.config.compilerOptions!.rootDir!, "/**/*.ts"));
        vscode.window.showInformationMessage("watching" + wsp.uri.fsPath);

        // ext._onDidChangeFile = new vscode.EventEmitter<vscode.FileChangeEvent[]>();
    }
    watcher.onDidChange((uri: vscode.Uri) => {
        vscode.window.showInformationMessage("onDidChange! " + uri.fsPath);
        // ext._onDidChangeFile.fire();
    });
    watcher.onDidCreate((uri: vscode.Uri) => {
        vscode.window.showInformationMessage("change onDidCreate! " + uri.fsPath);
    });
    watcher.onDidDelete((uri: vscode.Uri) => {
        vscode.window.showInformationMessage("change onDidDelete! " + uri.fsPath);
    });
    // ext._onDidChangeFile.event(() => {
    //     vscode.window.showInformationMessage("change _onDidChangeFile! ");
    // });
}
