
import * as fs from "fs";
import * as path from "path";
import * as vscode from "vscode";

import * as license from "gondola-license";
import { WebPanel } from "../common/webPanel";
import {
    licenseEditions,
    licenseForm,
    msgCmds,
    paths,
} from "../constantTexts";

import { IWebPanelMessageListener } from "../common/types";
import { ext } from "../extensionVariables";
import { info } from "../output";
import * as util from "../utils";
import { localize } from "./../localize";
import { checkLicense, notifyConnection } from "./checkLicense";

let licenseView: WebPanel;

class LicenseListener implements IWebPanelMessageListener {

    public async onMessage(command: string, payload: any) {
        switch (command) {
            case "checkLicense":
                license.checkoutLicense();
                ext.licenseServer.host = payload.host;
                ext.licenseServer.port = payload.port;
                ext.sidebarDataProvider.onDidChangeTreeDataEmitter.fire(undefined);

                util.statusBar.start(
                    localize("extension.status.connecting", " Connecting to License Server..."),
                    () => {
                        util.postMessage({ command: msgCmds.disableBtnOK });
                    });

                const licenseInfo = await checkLicense(payload.host, payload.port);

                util.statusBar.stop(() => {
                    util.postMessage({ command: msgCmds.enableBtnOK });
                });

                if (licenseView) {
                    licenseView.postMessage({
                        command: msgCmds.licenseInfo,
                        payload: licenseInfo,
                    });
                    notifyConnection(license.getLicenseState().state);
                }

                break;
        }
    }
    public async dispose() { }

}

export async function showLicenseForm() {

    info("showLicenseForm");
    if (!licenseView || !licenseView.isValid()) {
        licenseView = new WebPanel(
            new LicenseListener(),
            ["./assets/html/license"],
            getLicenseForm,
            licenseForm.gondolaLicense);

        initLicenseData();

        licenseView.postMessage({
            command: msgCmds.licenseServer,
            payload: ext.licenseServer,
        });
    } else {
        licenseView.show();
    }

}
function initLicenseData() {
    const licenseStatus = license.getLicenseState();
    const isValid = licenseStatus.state === license.Status.valid;
    const server = license.getServerInfo();
    ext.licenseServer.host = server.host;
    ext.licenseServer.port = server.port;
    ext.licenseServer.licenseInfo.expiredDate = licenseStatus.expirDate;
    ext.licenseServer.licenseInfo.instanceID = licenseStatus.instanseId;
    ext.licenseServer.licenseInfo.licenseState = licenseStatus.state;
    if (isValid && licenseStatus.trial) {
        ext.licenseServer.licenseInfo.licenseEdition = licenseEditions.trial;
    } else if (isValid && !licenseStatus.trial) {
        ext.licenseServer.licenseInfo.licenseEdition = licenseEditions.enterprise;
    } else {
        ext.licenseServer.licenseInfo.licenseEdition = "";
    }
}

async function getLicenseForm(): Promise<string> {
    const htmlPath = ext.context.asAbsolutePath(paths.licenseformPath);
    const cssPath = ext.context.asAbsolutePath(`assets/html/license/style.css`);

    let content = fs.readFileSync(htmlPath, "utf8");
    const cssContent = fs.readFileSync(cssPath, "utf8");

    // css replace
    content = content.replace("/* %CSS_CONTENT% */", cssContent);

    content = content.replace("%MANAGE_LICENSE%", licenseForm.manageLicense);
    content = content.replace("%LICENSE_SERVER%", licenseForm.licenseServer);
    content = content.replace("%MACHINE%", licenseForm.machine);
    content = content.replace("%PORT_NUMBER%", licenseForm.portNumber);
    content = content.replace("%OK%", licenseForm.ok);
    content = content.replace("%LICENSE_INFORMATION%", licenseForm.licenseInformation);
    content = content.replace("%EDITION%", licenseForm.edition);
    content = content.replace("%EXPIRY_DATE%", licenseForm.expiryDate);
    content = content.replace("%INSTANCE_ID%", licenseForm.instanceId);

    // add script
    const scriptPath = util.formatVsRes("assets/html/license/script.js");
    content = content.replace("%SCRIPT%", scriptPath);

    return content;
}
