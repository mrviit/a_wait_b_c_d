
import * as vscode from "vscode";
import { ViewType } from "../common/types";
import { openNewABTEditor } from "./openWithABTEditor";

export async function newPage(fileUri: vscode.Uri) {
    openNewABTEditor(fileUri, ViewType.PAGE_OBJECT_VIEW);
}
