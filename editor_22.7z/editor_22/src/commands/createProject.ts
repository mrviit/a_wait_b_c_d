import AdmZip from "adm-zip";
import * as fs from "fs-extra";
import * as path from "path";
import * as vscode from "vscode";

import * as texts from "../constantTexts";
import { ext } from "../extensionVariables";
import { terminalService } from "../terminals/terminalExecution";
import { localize } from "./../localize";
import { checkLicenseWhenCreateProject, checkOutLicense } from "./checkLicense";

// tslint:disable-next-line:no-var-requires
const npmPackageNameValidator = require("validate-npm-package-name");

interface IGondolaProjectTemplateConfig {
    templates: {
        [template: string]: {
            "path": string;
            "zipped": boolean;
        },
    };
    gondolaFW: string;
}

enum EDITORS { vscode = "option.editor.vscode", gse = "option.editor.gse" }

export async function createProject() {
    const isValid = await checkLicenseWhenCreateProject();
    if (!isValid) {
        const respond = await vscode.window.showErrorMessage(
            texts.messages.requireInputLicense,
            texts.buttonTexts.manageLicense);

        if (respond === texts.buttonTexts.manageLicense) {
            vscode.commands.executeCommand(texts.extensionCmds.showLicenseForm);
        }
        return;
    }

    const selectedFolder = await selectFolder();
    if (!selectedFolder) {
        return;
    }

    // const editor = await selectDefaultEditor();
    // if (!editor) {
    //     return;
    // }

    const templatesconfigPath = ext.context.asAbsolutePath(texts.paths.templatesconfigPath);
    const templatesconfig: IGondolaProjectTemplateConfig =
        await JSON.parse(fs.readFileSync(templatesconfigPath, "utf8"));
    const selectedTemplate = await selectTemplate(templatesconfig);
    if (!selectedTemplate) {
        return;
    }

    const projectName = await acquireProjectName(selectedFolder);
    if (projectName) {
        const projectDir = path.join(selectedFolder, projectName);
        await deployTemplate(templatesconfig, selectedTemplate, projectDir);

        const fwFolder = "lib";
        const fullPath = await createFrameworkDir(projectDir, fwFolder);
        await copyFramework(templatesconfig.gondolaFW, fullPath);

        let relativePath = path.join(fwFolder, templatesconfig.gondolaFW);
        relativePath = "./" + relativePath.replace(/\\/g, "/");
        await updateProjectParam(projectDir, { projectName, relativePath });
        await installFramework(projectDir);

        await checkOutLicense();

        if (ext.licensePanel) {
            ext.licensePanel.dispose();
        }
        vscode.workspace.updateWorkspaceFolders(0, null, { uri: vscode.Uri.file(projectDir) });

        showExplorer();

        // ext.context.workspaceState.update(texts.keys.defaultEditor, editor);
    }
}

async function selectDefaultEditor()
    : Promise<string | undefined> {
    const defaultEditor = [EDITORS.vscode, EDITORS.gse];
    const arrayText: any[] = [];
    for (const editor of defaultEditor) {
        const label = localize(editor, editor);
        arrayText.push({ ins: editor, label });
    }

    const selectedOption = await vscode.window.showQuickPick(arrayText,
        { placeHolder: texts.placeHolder.selectEditor });
    if (selectedOption) {
        return selectedOption.ins;
    }
    return undefined;
}

async function selectTemplate(templatesconfig: IGondolaProjectTemplateConfig)
    : Promise<string | undefined> {

    const templates = Object.keys(templatesconfig.templates);

    const arrayText: any[] = [];
    for (const ins of templates) {
        const label = localize(ins, ins);
        arrayText.push({ ins, label });
    }

    const selectedOption = await vscode.window.showQuickPick(arrayText,
        { placeHolder: texts.placeHolder.selectTemplate });
    if (selectedOption) {
        return selectedOption.ins;
    }
    return undefined;
}

async function selectFolder(): Promise<string | undefined> {
    let locationHistory = ext.context.globalState.get(texts.keys.globalState) as
        Array<{ label: string, description: string }>;
    if (!locationHistory) {
        locationHistory = [];
    }
    const browseButton = { label: texts.paths.browseLabel, description: "" };
    const quicklist = [...locationHistory, browseButton];
    const selectedFolder = await vscode.window.showQuickPick(
        quicklist,
        { placeHolder: texts.placeHolder.selectFolder },
    );

    if (selectedFolder === browseButton) {
        const browsingFolder = await vscode.window.showOpenDialog({
            canSelectFolders: true,
            canSelectFiles: false,
            canSelectMany: false,
        });
        if (browsingFolder) {
            const browsingPath = browsingFolder[0].fsPath;
            if (!locationHistory.find((aHistory) => {
                return aHistory.description === browsingPath;
            })) {
                locationHistory.unshift({
                    label: path.basename(browsingPath),
                    description: browsingPath,
                });
                await ext.context.globalState.update(texts.keys.globalState, locationHistory);
            }
            return browsingPath;
        }
    }

    if (selectedFolder) {
        return selectedFolder.description;
    }
}

async function acquireProjectName(selectedFolder: string): Promise<string | undefined> {
    let projectName = await vscode.window.showInputBox({ placeHolder: texts.placeHolder.projectName });

    while (projectName || projectName === "") {
        const validateResult = npmPackageNameValidator(projectName);
        if (!validateResult.validForNewPackages) {
            let message = "";
            if (validateResult.errors) {
                message = validateResult.errors.join(", ");
            } else if (validateResult.warnings) {
                message = validateResult.warnings.join(", ");
            }
            message += texts.messages.moreInfoProjectName;
            vscode.window.showErrorMessage(texts.messages.invalidProjectName + message);
            projectName = await vscode.window.showInputBox({ placeHolder: texts.placeHolder.projectName });
            continue;
        }
        const projectDir = path.join(selectedFolder, projectName);
        if (fs.existsSync(projectDir)) {
            const respond = await vscode.window.showErrorMessage(
                texts.messages.duplicatedProjectName(projectName),
                texts.buttonTexts.close);
            if (respond === texts.buttonTexts.close) {
                projectName = await vscode.window.showInputBox({ placeHolder: texts.placeHolder.projectName });
                continue;
            }
        }
        break;
    }

    return projectName;
}

async function deployTemplate(
    templatesconfig: IGondolaProjectTemplateConfig,
    selectedTemplate: string,
    projectDir: string) {

    let templatePath = templatesconfig.templates[selectedTemplate].path;
    templatePath = ext.context.asAbsolutePath(texts.paths.templatesPath + templatePath);
    const zipType = templatesconfig.templates[selectedTemplate].zipped as unknown as boolean;
    if (zipType) {
        const zip = new AdmZip(templatePath);
        zip.extractAllTo(projectDir);
        // await extract(templatePath, { dir: projectDir }, () => { });
    } else {
        fs.copySync(templatePath, projectDir);
    }

    updateProjectDir(projectDir);
}

async function updateProjectDir(projectDir: string) {
    const filePath = path.join(projectDir, "gondola.json");
    let content = fs.readFileSync(filePath, "utf8");
    const dir = projectDir.replace(/\\/g, "/");
    content = content.replace("<%= projectDir %>", dir);
    fs.writeFile(filePath, content);
}

async function createFrameworkDir(projectDir: string, newFolder: string): Promise<string> {
    const dir = path.join(projectDir, newFolder);
    await fs.mkdir(dir);
    return dir;
}

async function copyFramework(gondolaFW: string, destFWDir: string) {
    const src = ext.context.asAbsolutePath(texts.paths.templatesPath + gondolaFW);
    const dst = path.join(destFWDir, gondolaFW);
    await fs.copyFile(src, dst);
}

async function updateProjectParam(projectDir: string, params: { projectName: string, relativePath: string }) {
    const filePath = path.join(projectDir, "package.json");
    let content = fs.readFileSync(filePath, "utf8");
    content = content.replace("<%= name %>", params.projectName);
    content = content.replace("<%= gondolapath %>", params.relativePath);
    fs.writeFile(filePath, content);
}

async function installFramework(projectDir: string) {
    try {
        // execute npm install via terminal
        await terminalService.execute("npm", ["i"], projectDir);

    } catch (err) {
        vscode.window.showErrorMessage(`${texts.errorMessages.description}: ${err.message}`);
    }
}

function showExplorer() {
    vscode.commands.executeCommand("workbench.view.explorer");
}
