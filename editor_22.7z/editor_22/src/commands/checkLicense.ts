import * as license from "gondola-license";
import * as vscode from "vscode";
import * as texts from "../constantTexts";
import { ext } from "../extensionVariables";
import * as util from "./../utils";
let intervalUpdate = false;

interface ILicenseInfo {
    licenseState: license.Status;
    licenseEdition: string;
    expiredDate: string;
    instanceID: string;
}

export async function checkOutLicense() {
    await license.stop();
}

async function checkInLicense(server?: string) {
    license.setPrefixDeviceInfo("EXT");
    if (server !== undefined) {
        license.setServerInfo(server);
    }
    await license.checkinLicense();
}

export async function checkLicense(host: string, port: number): Promise<ILicenseInfo> {
    const licenseInfo: ILicenseInfo = {
        licenseState: license.Status.unknown,
        licenseEdition: "",
        expiredDate: "",
        instanceID: "",
    };

    const serverInfo = host + ":" + port;
    await checkInLicense(serverInfo);
    const status = license.getLicenseState();
    updateStatusBar(status.state);

    const result = (status.state === license.Status.valid);
    if (result) {
        if (!intervalUpdate && !status.trial) {
            intervalUpdate = true;
            const hearbeat = Number(status.heartbeat);
            setInterval(updateLicense, hearbeat);
        }

        licenseInfo.licenseState = status.state;
        licenseInfo.licenseEdition = status.trial ? texts.licenseEditions.trial : texts.licenseEditions.enterprise;
        licenseInfo.expiredDate = status.expirDate;
        licenseInfo.instanceID = status.instanseId;
    }

    return licenseInfo;
}

async function updateLicense() {
    await license.checkinLicense();
    let status = license.getLicenseState();
    if (status.state === license.Status.error && status.redundancy !== "") {
        await license.tryCheckinLicense();
        status = license.getLicenseState();
    }
    updateStatusBar(status.state);
}

export async function checkLicenseWhenActive() {
    util.statusBar.start(texts.statusBar.connecting);
    await checkInLicense();
    util.statusBar.stop();
    const status = license.getLicenseState();
    updateStatusBar(status.state);
    if (status.state === license.Status.valid && !status.trial) {
        const hearbeat = Number(status.heartbeat);
        intervalUpdate = true;
        setInterval(updateLicense, hearbeat);
    }

}

export async function checkLicenseWhenCreateProject() {
    let result = true;
    const status = license.getLicenseState();
    if (status.state !== license.Status.valid) {
        // show popup here
        // ....

        result = false;
    }
    return result;
}

function updateStatusBar(state: license.Status): void {
    if (state === license.Status.valid) {
        ext.statusBarItem.text = texts.statusBar.succeed;
        ext.statusBarItem.color = "#00FF00";
    } else {
        ext.statusBarItem.text = texts.statusBar.failed;
        ext.statusBarItem.command = texts.extensionCmds.showLicenseForm;
        ext.statusBarItem.color = "#FF0000";
    }

    ext.statusBarItem.show();
    ext.context.subscriptions.push(ext.statusBarItem);
    setTimeout(() => {
        cleanStatusBar();
    }, 6000);
}
function cleanStatusBar() {
    ext.statusBarItem.hide();
}

export function notifyConnection(code: license.Status) {
    switch (code) {
        case license.Status.expired:
            vscode.window.showErrorMessage(texts.errorMessages.expireMessage);
            break;
        case license.Status.invalid:
        case license.Status.error:
            vscode.window.showErrorMessage(texts.errorMessages.invalidMessage);
            break;
        case license.Status.full:
            vscode.window.showErrorMessage(texts.errorMessages.fullMessage);
            break;
        default:
            break;
    }
}
