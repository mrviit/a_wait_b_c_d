
import * as fs from "fs-extra";
import * as vscode from "vscode";

import path from "path";
import { IWebPanelMessageListener, ViewType } from "../common/types";
import { WebPanel } from "../common/webPanel";
import { paths, spreadsheetForm } from "../constantTexts";
import * as texts from "../constantTexts";
import { ext } from "../extensionVariables";
import { info } from "../output";
import { formatVsRes } from "../utils";

import {
    getDict, loadTSToSE, saveAsTypeScript,
} from "../clientipc/client";

interface ISpreadSheetEditor {
    [index: string]: WebPanel;
}
const spreadsheet = {} as ISpreadSheetEditor;

const htmlProvider = new Map();
htmlProvider.set(ViewType.TEST_VIEW, getTestGridView);
htmlProvider.set(ViewType.PAGE_OBJECT_VIEW, getPageGridView);

// command to open spreadsheet editor
export async function openWithABTEditor(fileUri: vscode.Uri) {
    info(`SE view of [${fileUri.fsPath}] is loading`);

    const workspace = vscode.workspace.getWorkspaceFolder(fileUri);
    if (!workspace) {
        vscode.window.showInformationMessage("The file must be in an workspace");
        return;
    }

    const workspaceDir = workspace.uri.fsPath;
    const filePath = fileUri.fsPath;

    const fileType = getFileType(filePath);
    // FIXME : optimize await later
    const actionDict = await getDict(workspaceDir);

    const promiseShowSE = showABTEditor(workspaceDir, filePath, fileType);
    const promiseGetData = loadTSToSE(workspaceDir, filePath, fileType);

    const [seControl, returnedData] = await Promise.all([promiseShowSE, promiseGetData]);
    seControl!.postMessage({
        command: "injectData",
        payload: returnedData,
    });

    seControl!.postMessage({
        command: "injectDict",
        payload: actionDict,
    });
}

export async function openNewABTEditor(fileUri: vscode.Uri, fileType: number) {
    info(`SE view of [${fileUri.fsPath}] is loading`);

    const workspace = vscode.workspace.getWorkspaceFolder(fileUri);
    if (!workspace) {
        vscode.window.showInformationMessage("The file must be in an workspace");
        return;
    }

    const workspaceDir = workspace.uri.fsPath;
    const filePath = fileUri.fsPath;

    const promiseShowSE = showABTEditor(workspaceDir, filePath, fileType);
    const promiseGetDict = getDict(workspaceDir);

    const [seControl, actionDict] = await Promise.all([promiseShowSE, promiseGetDict]);
    seControl!.postMessage({
        command: "injectData",
        payload: null,
    });

    seControl!.postMessage({
        command: "injectDict",
        payload: actionDict,
    });
}

export async function exportData() {
    Object.entries(spreadsheet).forEach(
        async ([index, editor]) => {
            if (editor.isVisible()) {
                await editor.postMessage({ command: "exportData" });
            }
        },
    );
}

function getEditor(index: string) {
    return spreadsheet[index];
}

function getFileType(filePath: string) {
    const content = fs.readFileSync(filePath, "utf8");

    if (content.length > 0 && content.includes("TestModule") === false) {
        return ViewType.PAGE_OBJECT_VIEW;
    }

    return ViewType.TEST_VIEW;
}

async function showABTEditor(workingDir: string, filePath: string, fileType: number) {
    let editorName = path.parse(filePath).name;
    let name = filePath;
    if (fs.statSync(filePath).isDirectory()) {
        editorName = "Untitled.ts";
        name = path.join(filePath, "Untitled.ts");
    }
    let spreadsheetEditor = getEditor(name);

    if (!spreadsheetEditor || !spreadsheetEditor.isValid()) {
        spreadsheetEditor = new WebPanel(
            new SpreadsheetListener(name, workingDir, filePath),
            ["assets/html/spreadsheet", "assets/res"],
            htmlProvider.get(fileType),
            editorName);
        spreadsheet[name] = spreadsheetEditor;
    } else {
        await spreadsheetEditor.show();
    }
    return spreadsheetEditor;
}

function formatScript(jsPaths: string[]) {
    let sScript = ``;
    for (const curPath of jsPaths) {
        const realPath = formatVsRes(curPath);
        sScript += `<script src="${realPath}"></script>\n`;
    }
    return sScript;
}
async function getTestGridView(): Promise<string> {
    const htmlPath = ext.context.asAbsolutePath(paths.abtEditor);
    let content = fs.readFileSync(htmlPath, "utf8");
    content = await formatCommonHTML(content);

    const jsPaths = [
        "assets/html/spreadsheet/test_edittor/test_eventhandler.js",
    ];

    const SE_SCRIPTS = formatScript(jsPaths);
    content = content.replace("<!-- %SE_SCRIPTS% -->", SE_SCRIPTS);

    content = content.replace(/%TEST_HOOK_TITLE%/g, spreadsheetForm.secConfigsTitle);
    content = content.replace(/%TEST_CASE_TITLE%/g, spreadsheetForm.secTestCasesTitle);

    return content;
}

async function getPageGridView(): Promise<string> {
    const htmlPath = ext.context.asAbsolutePath(paths.pageObjectEditor);
    let content = fs.readFileSync(htmlPath, "utf8");
    content = await formatCommonHTML(content);

    const jsPaths = [
        "assets/html/spreadsheet/page_object_editor/po_eventhandler.js",
    ];

    const SE_SCRIPTS = formatScript(jsPaths);
    content = content.replace("<!-- %SE_SCRIPTS% -->", SE_SCRIPTS);

    content = content.replace(/%LOCATORS_TITLE%/g, spreadsheetForm.secLocatorsTitle);

    content = content.replace(/%METHODS_TITLE%/g, spreadsheetForm.secMethodssTitle);

    return content;
}

async function formatCommonHTML(htmlContent: string): Promise<string> {
    let content = await formatStyleInHTML(htmlContent);
    content = content.replace("%AG_GRID%", formatVsRes("assets/html/spreadsheet/common/ag-grid-community.min.js"));

    const jsPaths = [
        "assets/html/spreadsheet/common/autocomplete.js",
        "assets/html/spreadsheet/common/celleditor.js",
        "assets/html/spreadsheet/common/common_ag_grid.js",
    ];

    const COMMON_SCRIPT = formatScript(jsPaths);
    content = content.replace("<!-- %COMMON_SCRIPTS% -->", COMMON_SCRIPT);

    const iconAddLine = formatVsRes("assets/res/add-line.svg");
    content = content.replace(/%ICON_ADD_LINE%/g, iconAddLine);

    const iconRemoveLine = formatVsRes("assets/res/delete-line.svg");
    content = content.replace(/%ICON_REMOVE_LINE%/g, iconRemoveLine);

    const iconCollapse = formatVsRes("assets/res/nav-down.svg");
    content = content.replace(/%ICON_COLLAPSE%/g, iconCollapse);

    const iconExpand = formatVsRes("assets/res/nav-up.svg");
    content = content.replace(/%ICON_EXPAND%/g, iconExpand);

    content = content.replace(/%BTN_SAVE%/g, spreadsheetForm.btnSave);

    return content;
}

async function formatStyleInHTML(htmlContent: string): Promise<string> {
    const style = formatVsRes("assets/html/spreadsheet/common/editor_style.css");
    const SE_STYLE = `<link rel="stylesheet" href="${style}">`;

    const content = htmlContent.replace("<!-- %SE_STYLES% -->", SE_STYLE);
    return content;
}

/**
 * handle message from webview control
 */
class SpreadsheetListener implements IWebPanelMessageListener {
    private handlers: any;
    private path: string;
    private name: string;
    private workingDir: string;
    public constructor(name: string, workingDir: string, filePath: string) {
        this.handlers = {};
        this.handlers["exportData"] = this.exportData;
        this.workingDir = workingDir;
        this.path = filePath;
        this.name = name;
    }

    public async onMessage(command: string, payload: any) {
        let handler = this.handlers[command];
        if (handler) {
            handler = handler.bind(this, payload);
            handler(payload);
        }
    }

    public async dispose() { }

    private async exportData(payload: any) {
        const data = payload;
        if (fs.statSync(this.path).isDirectory()) {
            const filename = await vscode.window.showInputBox({ placeHolder: texts.placeHolder.enterFileName });
            if (!filename) { return; }
            // TODO: check filename valid
            this.path = path.join(this.path, filename + ".ts");
            const spreadsheetEditor = getEditor(this.name);
            spreadsheet[this.path] = spreadsheetEditor;
            delete spreadsheet[this.name];
            this.name = this.path;
            spreadsheetEditor.changeTitle(filename);
        }
        saveAsTypeScript(this.workingDir, this.path, data);
    }
}
