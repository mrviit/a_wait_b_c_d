import * as path from "path";
import { window, workspace } from "vscode";
import { ext } from "../extensionVariables";

import {
    LanguageClient,
    LanguageClientOptions,
    ServerOptions,
    State as ClientState,
    TransportKind,
} from "vscode-languageclient";
import {
    error,
} from "../output";

export let client: LanguageClient;

let promiseClientAvaliable: Promise<void>;

export async function registerAndWaitClientReady() {
    if (!promiseClientAvaliable) {
        promiseClientAvaliable = registerClientImpl();
    }
    await promiseClientAvaliable;
    return client!;
}

async function registerClientImpl() {

    // The server is implemented in node
    const serverModule = ext.context.asAbsolutePath(
        path.join("server", "out", "server.js"),
    );
    // The debug options for the server
    // --inspect=6009: runs the server in Node's Inspector mode so VS Code can attach to the server for debugging
    const debugOptions = { execArgv: ["--nolazy", "--inspect=6009"] };

    // If the extension is launched in debug mode then the debug server options are used
    // Otherwise the run options are used
    const serverOptions: ServerOptions = {
        run: { module: serverModule, transport: TransportKind.ipc },
        debug: {
            module: serverModule,
            transport: TransportKind.ipc,
            options: debugOptions,
        },
    };

    // Options to control the language client
    const clientOptions: LanguageClientOptions = {
        // Register the server for plain text documents
        // documentSelector: [{ scheme: 'file', language: 'plaintext' }],
        synchronize: {
            // Notify the server about file changes to '.clientrc files contained in the workspace
            fileEvents: workspace.createFileSystemWatcher("**/.clientrc"),
        },
        outputChannel: ext.outputChanel,
    };

    try {
        // Create the language client and start the client.
        client = new LanguageClient(
            "gondola_language_server",
            "Gondola Language Server",
            serverOptions,
            clientOptions,
        );
    } catch (error) {
        // tslint:disable-next-line: max-line-length
        window.showErrorMessage(`The Gondola server extension couldn't be started. See the Gondola output channel for details.`);
        return;
    }

    const running = "Gondola server is running.";
    const stopped = "Gondola server stopped.";
    client.onDidChangeState((event) => {
        if (event.newState === ClientState.Running) {
            client.info(running);
        } else {
            client.info(stopped);
        }
    });

    // Start the client. This will also launch the server
    client.start();

    await client.onReady();
    client.info("Start LSP");
}

export function unregisterClient() {
    if (!client) {
        return undefined;
    }
    return client.stop();
}

const LoadTypeScript = "load_ts_to_se";
const SaveAsTypeScript = "save_se_as_ts";
const GetDict = "se_get_dict";

export async function loadTSToSE(workingDir: string, filePath: string,  fileType: number) {
    try {
        await registerAndWaitClientReady();
        const ret = await client!.sendRequest(LoadTypeScript, {workingDir, filePath, fileType});
        return ret;
    } catch (err) {
        error(err);
    }
}

export async function saveAsTypeScript(workingDir: string, filePath: string, data: any[]) {
    try {
        await registerAndWaitClientReady();
        client!.sendRequest(SaveAsTypeScript, { workingDir, filePath, data });
    } catch (err) {
        error(err);
    }
}

export async function getDict(projectPath: string) {
    const dictsMap: Map<string, any> = new Map<string, any>();
    try {
        let dict = dictsMap.get(projectPath);
        if (!dict) {
            await registerAndWaitClientReady();
            dict = await client!.sendRequest(GetDict, projectPath);
            dictsMap.set(projectPath, dict);
        }
        return dict;
    } catch (err) {
        error(err);
    }
}
