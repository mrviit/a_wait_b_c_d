
/**
 * keep all extension variable here
 */
import * as vscode from "vscode";

import { GondolaSideBarDataProvider } from "./sidebar/GondolaSideBarDataProvider";

export namespace ext {
    // export let _onDidChangeFile: vscode.EventEmitter<vscode.FileChangeEvent[]>;
    export let context: vscode.ExtensionContext;
    export let defaultItemColor: string | vscode.ThemeColor | undefined;
    export let licensePanel: vscode.WebviewPanel | undefined;
    export let abtEditor: vscode.WebviewPanel | undefined;
    export let licenseActivated: Promise<void>;
    export const name = "Gondola";
    export let outputChanel: vscode.OutputChannel;
    export let sidebar: vscode.TreeView<vscode.TreeItem>;
    export let sidebarDataProvider: GondolaSideBarDataProvider;
    export let statusBarItem: vscode.StatusBarItem;
    export const licenseServer = {
        host: "",
        port: "",
        licenseInfo: {
            licenseState: -1,
            licenseEdition: "",
            expiredDate: "",
            instanceID: "",
        },
    };
}
