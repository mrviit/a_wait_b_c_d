
import * as fs from "fs";
import * as path from "path";
import { promisify } from "util";
import * as vscode from "vscode";
import { ext } from "./extensionVariables";

export const readFile = promisify(fs.readFile);
export const writeFile = promisify(fs.writeFile);

export function registerCommand(commandId: string, callback: (...arg: any) => any): void {
    const disposable = vscode.commands.registerCommand(commandId, callback);
    ext.context.subscriptions.push(disposable);
}

export function registerOutputChanel(): void {
    // Create OutputChannel
    const outputChannel = vscode.window.createOutputChannel(ext.name);
    ext.context.subscriptions.push(outputChannel);
    ext.outputChanel = outputChannel;

}

export function postMessage(message: { command: string }) {
    if (ext.licensePanel) {
        ext.licensePanel.webview.postMessage(message);
    }
}

export async function sleep(milliseconds: number) {
    return new Promise<void>((resolve) => setTimeout(resolve, milliseconds));
}

export namespace statusBar {
    const frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
    let index = 0;
    function loading(message: string) {
        ext.statusBarItem.text = frames[index = ++index % frames.length] + message;
        ext.statusBarItem.color = ext.defaultItemColor;
        ext.statusBarItem.show();
    }
    let processing: NodeJS.Timeout;
    export function start(loadingMessage: string, action?: (() => any)) {
        processing = setInterval(loading, 100, loadingMessage) as any;
        if (ext.licensePanel && action) {
            action();
        }
    }

    export function stop(action?: (() => any)) {
        clearInterval(processing);
        if (ext.licensePanel && action) {
            action();
        }
    }
}

export enum OSType {
    Unknown = "Unknown",
    Windows = "Windows",
    OSX = "OSX",
    Linux = "Linux",
}

/**
 * format a file path for webview panel
 * @param path relative path of resource
 */
export function formatVsRes(resPath: string ): string {
    const agGridJs = path.join(ext.context.extensionPath, resPath);
    const agGridUri = vscode.Uri.file(agGridJs);
    const agGridRsc = agGridUri.with({ scheme: "vscode-resource" });
    return agGridRsc.toString();
}

function getOSType(platform: string = process.platform): OSType {
    if (/^win/.test(platform)) {
        return OSType.Windows;
    } else if (/^darwin/.test(platform)) {
        return OSType.OSX;
    } else if (/^linux/.test(platform)) {
        return OSType.Linux;
    } else {
        return OSType.Unknown;
    }
}

export namespace Platform {
    export const osType = getOSType();
    export function isWindows(): boolean {
        return osType === OSType.Windows;
    }
    export function isMac(): boolean {
        return osType === OSType.OSX;
    }
    export function isLinux(): boolean {
        return osType === OSType.Linux;
    }
}
