
import {ext} from "./extensionVariables";

// Writes date and message to the output channel
function outputLine( prefix: string, message: string ) {
    if (ext.outputChanel) {
        const datePrefix = `[${prefix}  - ${ (new Date()).toLocaleTimeString()} ]`;
        ext.outputChanel.appendLine(datePrefix + message);
    }
}

const TAG = {
    ERROR : "ERR",
    WARNAING : "WARN",
    INFO : "INFO",
};

export function error( message: string ) {
    outputLine(TAG.ERROR, message);
}

export function warn( message: string ) {
    outputLine(TAG.WARNAING, message);
}

export function info( message: string ) {
    outputLine(TAG.INFO, message);
}

/**
 * used to log information for debugging. 
 * It only show information when trace mode is enable (not implement yet)
 * @param message information
 */
export function log( message: string ) {
    outputLine(TAG.INFO, message);
}
