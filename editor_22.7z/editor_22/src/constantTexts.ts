import { localize } from "./localize";

export namespace licenseForm {
    export const gondolaLicense = localize("view.license.gondolalicense", "Gondola License");
    export const enterprise = localize("view.license.enterprise", "Enterprise");
    export const manageLicense = localize("view.license.managelicense", "Manage License");
    export const licenseServer = localize("view.license.licenseserver", "LICENSE SERVER");
    export const machine = localize("view.license.machine", "Machine");
    export const portNumber = localize("view.license.portnumber", "Port Number");
    export const ok = localize("view.license.ok", "OK");
    export const licenseInformation = localize("view.license.licenseinformation", "LICENSE INFORMATION");
    export const edition = localize("view.license.edition", "Edition");
    export const expiryDate = localize("view.license.expirydate", "Expiry date");
    export const instanceId = localize("view.license.instanceid", "Instance ID");
    export const browse = localize("inputbox.browse", "Browse...");
}

export namespace spreadsheetForm {
    export const secConfigsTitle = localize("view.se.section.config.title", "TEST CONFIGURATIONS");
    export const secTestCasesTitle = localize("view.se.section.testcase.title", "TEST CASES");
    export const secLocatorsTitle = localize("view.se.section.locators.title", "LOCATORS");
    export const secMethodssTitle = localize("view.se.section.methods.title", "METHODS");

    export const btnSave = localize("view.se.button.save", "Save");

    export const kTestCase = localize("view.se.keyword.testcase", "Test Case");
    export const kTestStep = localize("view.se.keyword.teststep", "Test Step");
    export const kBeforeSuite = localize("view.se.keyword.beforesuite", "Initial Suite");
    export const kAfterSuite = localize("view.se.keyword.aftersuite", "Final Suite");
    export const kBeforeTest = localize("view.se.keyword.beforetest", "Initial Test");
    export const kAfterTest = localize("view.se.keyword.aftertest", "Final Test");
}

export namespace paths {
    export const templatesPath = "templates/projects/";
    export const templatesconfigPath = "templates/projects/templatesconfig.json";
    export const licenseformPath = "assets/html/license/index.html";
    export const abtEditor = "assets/html/spreadsheet/test_edittor/test_editor.html";
    export const pageObjectEditor = "assets/html/spreadsheet/page_object_editor/po_editor.html";
    export const browseLabel = "$(file-directory) " + licenseForm.browse;
}

export namespace keys {
    export const globalState = "gondolaLocationHistory";
    export const defaultEditor = "defaultEditor";
}

export namespace errorMessages {
    export const description = localize("extension.error.description",
        "An error occurred while running the task");
    export const invalidMessage = localize("extension.license.invalid",
        "Cannot connect to License Server. Please verify the machine name and port number.");
    export const fullMessage = localize("extension.license.full",
        // tslint:disable-next-line:max-line-length
        "The max number of users has been reached. Please contact your License Server administrator to purchase more licenses.");
    export const expireMessage = localize("extension.license.expired",
        // tslint:disable-next-line:max-line-length
        "Cannot validate your Gondola license. Please contact your License Server administrator or click [here](https://docs.gondolatest.com) to learn more.");
}

export namespace extensionCmds {
    export const showLicenseForm = "gondola.showLicenseForm";
    export const createProject = "gondola.createProject";
    export const openWithABTEditor = "gondola.openWithABTEditor";
    export const exportData = "gondola.exportData";
    export const newTest = "gondola.newTest";
    export const newPage = "gondola.newPage";
    export const watchSrc = "gondola.watchSrc";
}

export namespace messages {
    export const requireInputLicense = localize(
        "extension.messages.require_input_license",
        "Please input license information before using Gondola features.");
    export const invalidProjectName = localize(
        "extension.messages.invalid_project_name",
        "Invalid project name: ");
    export const moreInfoProjectName = localize(
        "extension.messages.more_info_project_name",
        ". [More infomation](https://www.npmjs.com/package/validate-npm-package-name).");
    export const duplicatedProjectName = (name: string) => {
        let msg = localize(
            "extension.messages.duplicated_project_name",
            `User name '%s' already exists at the specified location`);
        msg = msg.replace("%s", name);
        return msg;
    };
}

export namespace buttonTexts {
    export const close = localize("extension.buttons.close", "Close");
    export const ok = localize("extension.buttons.ok", "OK");
    export const manageLicense = localize("extension.buttons.manage_license", "Mange License");
}

export namespace licenseEditions {
    export const enterprise = localize("view.license.enterprise", "Enterprise");
    export const trial = localize("view.license.trial", "Trial");
}

export namespace msgCmds {
    export const licenseServer = "licenseServer";
    export const licenseInfo = "licenseInfo";
    export const enableBtnOK = "enableBtnOK";
    export const disableBtnOK = "disableBtnOK";
}

export namespace sideBar {
    export const id = "gondola";
    export const inputLicense = localize("extension.sidebar.input_license", "Input License ...");
    export const inputLicenseTitle = localize("extension.sidebar.input_license_title", "Input License");
}

export namespace statusBar {
    export const installing = localize("extension.status.installing", " Downloading dependencies...");
    export const failed = localize("extension.license.failed", "Failed to connect to License Server");
    export const succeed = localize("extension.license.succeed", "Connected to License Server successfully");
    export const connecting = localize("extension.status.connecting", " Connecting to License Server...");
}

export namespace placeHolder {
    export const selectTemplate = localize("extension.status.select_project_template_placeHolder",
        "Select a template");
    export const selectEditor = localize("extension.status.select_default_editor_placeHolder",
        "Select a default editor");
    export const selectFolder = localize("extension.status.select_folder_placeHolder",
        "Select a folder that will contain your project");
    export const projectName = localize("extension.status.project_name_place_holder",
        "Enter your project name");
    export const enterFileName = localize("extension.input_box.enter_file_name_place_holder",
        "Enter a file name");
}
