
"use strict";
import * as fs from "fs";
import {ext} from "./extensionVariables";
import { info } from "./output";

// resource collection
let loadedCollection: any;

/*
* get locale
*/
function locale(): string {
    const vsclocale = process.env.VSCODE_NLS_CONFIG;
    return vsclocale ? JSON.parse(vsclocale).locale : "en";
}

function load() {
    // Figure out our current locale.
    const loadedLocale = locale();

    // Find the nls file that matches (if there is one)
    let  nlsFile = ext.context.asAbsolutePath(`package.nls.${loadedLocale}.json`);
    if (!fs.existsSync(nlsFile)) {
        nlsFile = ext.context.asAbsolutePath(`package.nls.json`);
    }
    if (fs.existsSync(nlsFile)) {
        const contents = fs.readFileSync(nlsFile, "utf8");
        loadedCollection = JSON.parse(contents);
    }
}

export function localize(key: string, defValue: string): string  {

    const x = getString(key, defValue);

    info(` call locallize : ${key} : ${x}`);
    return x;
}

function getString(key: string, defValue: string) {
    // Load the current collection
    if (!loadedCollection ) {
        load();
    }

    // First lookup in the dictionary that matches the current locale
    if (loadedCollection && loadedCollection.hasOwnProperty(key)) {
        return loadedCollection[key];
    }
    return defValue;
}
