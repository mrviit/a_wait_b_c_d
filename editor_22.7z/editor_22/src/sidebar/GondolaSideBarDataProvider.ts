
import * as vscode from "vscode";

import * as license from "gondola-license";

import { extensionCmds, sideBar } from "../constantTexts";
import { ext } from "../extensionVariables";

export class GondolaSideBarDataProvider implements vscode.TreeDataProvider<vscode.TreeItem> {

    public readonly onDidChangeTreeDataEmitter: vscode.EventEmitter<vscode.TreeItem | null> =
        new vscode.EventEmitter<vscode.TreeItem | null>();

    public readonly onDidChangeTreeData: vscode.Event<vscode.TreeItem | null> = this.onDidChangeTreeDataEmitter.event;

    public getTreeItem(element: vscode.TreeItem): vscode.TreeItem | Thenable<vscode.TreeItem> {
        return element;
    }

    public getChildren(element?: vscode.TreeItem): vscode.ProviderResult<vscode.TreeItem[]> {
        if (element) {
            return null;
        }

        if (ext.licenseServer.host !== "" && ext.licenseServer.port !== "") {
            return null;
        }

        const serverInfo = license.getServerInfo();
        if (serverInfo && serverInfo.host && serverInfo.port) {
            return null;
        }

        const item = new vscode.TreeItem(sideBar.inputLicense);
        item.command = {
            command: extensionCmds.showLicenseForm,
            title: sideBar.inputLicenseTitle,
        };
        return [item];
    }
}
