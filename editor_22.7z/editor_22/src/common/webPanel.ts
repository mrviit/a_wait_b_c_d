import {
    IDisposableRegistry,
    IWebPanel,
    IWebPanelMessageListener,
    WebPanelMessage,
} from "./types";

import {
    Uri,
    ViewColumn,
    WebviewPanel,
    window,
} from "vscode";

import * as fs from "fs-extra";
import * as path from "path";
import { ext } from "../extensionVariables";

export class WebPanel implements IWebPanel {

    private listener: IWebPanelMessageListener;
    private panel: WebviewPanel | undefined;
    private loadPromise: Promise<void>;

    constructor(
        // serviceContainer: IServiceContainer,
        listener: IWebPanelMessageListener,
        resourceRoots: string[],
        htmlContentCallback: any,
        title: string) {

        const localRrcRoots = resourceRoots.map((rs) => Uri.file(path.join(ext.context.extensionPath, rs)));

        this.listener = listener;
        this.panel = window.createWebviewPanel(
            title.toLowerCase().replace(" ", ""),
            title,
            { viewColumn: ViewColumn.One, preserveFocus: true },
            {
                enableScripts: true,
                retainContextWhenHidden: true,
                localResourceRoots: localRrcRoots,
            });
        this.loadPromise = this.load(htmlContentCallback);
    }

    public async show() {
        await this.loadPromise;
        if (this.panel) {
            this.panel.reveal(this.panel.viewColumn, true);
        }
    }

    public isVisible(): boolean {
        return this.panel ? this.panel.visible : false;
    }

    public isValid(): boolean {
        if (this.panel) {
            return true;
        }
        return false;
    }

    public changeTitle(newTitle: string) {
        if (!this.panel) { return; }
        this.panel.title = newTitle;
    }

    public postMessage(message: WebPanelMessage) {
        if (this.panel && this.panel.webview) {
            this.panel.webview.postMessage(message);
        }
    }

    // tslint:disable-next-line:no-any
    private async load(htmlContentProvider: any) {
        if (this.panel) {
            const content = await htmlContentProvider();
            if (content) {
                this.panel.webview.html = content;
                // Reset when the current panel is closed
                this.panel.onDidDispose(() => {
                    this.panel = undefined;
                    this.listener.dispose();
                }, undefined, ext.context.subscriptions);

                this.panel.webview.onDidReceiveMessage((message) => {
                    // Pass the message onto our listener
                    this.listener.onMessage(message.command, message.payload);
                }, undefined, ext.context.subscriptions);
            } else {
                // Indicate that we can't load the file path
                this.panel.webview.html = `<html><body><h1>Webview is not a valid</h1></body></html>`;
            }
        }
    }
}
