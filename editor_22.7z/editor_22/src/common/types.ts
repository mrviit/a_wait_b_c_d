"use strict";
import {
    Disposable,
} from "vscode";

export type IDisposableRegistry = { push(disposable: Disposable): void };

export interface IDisposable {
    dispose(): void | undefined;
}
export interface IAsyncDisposable {
    dispose(): Promise<void>;
}

export interface IWebPanelMessageListener extends IAsyncDisposable {
    /**
     * Listens to web panel messages
     * @param message: the message being sent
     * @param payload: extra data that came with the message
     * @return A IWebPanel that can be used to show html pages.
     */
    onMessage(message: string, payload: any): void;
}

export type WebPanelMessage = {
    /**
     * Message type
     */
    command: string;

    /**
     * Payload
     */
    payload?: any;
};

// Wraps the VS Code webview panel
export const IWebPanel = Symbol("IWebPanel");
export interface IWebPanel {
    /**
     * Makes the webpanel show up.
     * @return A Promise that can be waited on
     */
    show(): Promise<void>;

    /**
     * Indicates if this web panel is visible or not.
     */
    isVisible(): boolean;

    /**
     * Sends a message to the hosted html page
     */
    postMessage(message: WebPanelMessage): void;
}

export enum ViewType {
    TEST_VIEW = 1,
    PAGE_OBJECT_VIEW,
}
